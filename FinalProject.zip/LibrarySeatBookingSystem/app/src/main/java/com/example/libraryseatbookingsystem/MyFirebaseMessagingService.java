//package com.example.libraryseatbookingsystem;
//
//import android.annotation.SuppressLint;
//import android.app.Notification;
//import android.app.NotificationChannel;
//import android.app.NotificationManager;
//import android.app.PendingIntent;
//import android.app.Service;
//import android.content.Context;
//import android.content.Intent;
//import android.graphics.Color;
//import android.os.Build;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.RequiresApi;
//import androidx.core.app.NotificationCompat;
//
//import com.google.firebase.messaging.FirebaseMessagingService;
//import com.google.firebase.messaging.RemoteMessage;
//
//import java.util.Random;
//
//public class MyFirebaseMessagingService extends FirebaseMessagingService {
//
//    private final String CHANNEL_ID = "senderchannel";
//    @RequiresApi(api = Build.VERSION_CODES.S)
//    @Override
//    public  void onMessageReceived(@NonNull RemoteMessage remoteMessage){
//
//        String title = remoteMessage.getData().get("title");
//        String message = remoteMessage.getData().get("message");
//
//        super.onMessageReceived(remoteMessage);
//        Intent intent = new Intent(this, MainActivity.class); //it can send notification to activity
//        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//        int notificationId = new Random().nextInt();
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            createNotificationChannel(manager);
//        }
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//
////        @SuppressLint("UnspecifiedImmutableFlag") PendingIntent intent1 =PendingIntent.getActivities(this,0,new Intent[]{intent},PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_MUTABLE);
//
//        intent.putExtra("displayPopup", true);
//        @SuppressLint("UnspecifiedImmutableFlag") PendingIntent intent1 = PendingIntent.getActivities(this, 0, new Intent[]{intent}, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
//
//        Intent dismissIntent = new Intent(this, NotificationDismissReceiver.class);
//        dismissIntent.putExtra("notificationId", notificationId);
//        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(this, 0, dismissIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
//
//
//        NotificationCompat.Builder builder = null;
//        Notification notification =null;
////        Notification.notification = null;
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            builder = new NotificationCompat.Builder(this,CHANNEL_ID)
//                    .setContentTitle(title)
//                    .setContentText(message)
//                    .setSmallIcon(R.drawable.baseline_notification_important_24)
//                    .setAutoCancel(true)
//                    .setContentIntent(intent1)
//                    .setContentIntent((intent1))
//                    .addAction(R.drawable.ic_dismiss,"Dismiss",dismissPendingIntent);
//            notification = builder.build();
//
//        }
//        manager.notify(notificationId,notification);
//    }
//
//    private void createNotificationChannel(NotificationManager manager) {
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,"channelName",NotificationManager.IMPORTANCE_HIGH);
//            channel.setDescription("My Description");
//            channel.enableLights(true);
//            channel.setLightColor(Color.WHITE);
//
//            manager.createNotificationChannel(channel);
//        }
//    }
//}
package com.example.libraryseatbookingsystem;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Random;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private final String CHANNEL_ID = "senderchannel";
    @RequiresApi(api = Build.VERSION_CODES.S)
    @Override
    public  void onMessageReceived(@NonNull RemoteMessage remoteMessage){

        String title = remoteMessage.getData().get("title");
        String message = remoteMessage.getData().get("message");

        super.onMessageReceived(remoteMessage);
        Intent intent = new Intent(this, MainActivity.class); //it can send notification to activity
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationId = new Random().nextInt();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel(manager);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

//        @SuppressLint("UnspecifiedImmutableFlag") PendingIntent intent1 =PendingIntent.getActivities(this,0,new Intent[]{intent},PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_MUTABLE);

        intent.putExtra("displayPopup", true);
        @SuppressLint("UnspecifiedImmutableFlag") PendingIntent intent1 = PendingIntent.getActivities(this, 0, new Intent[]{intent}, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

        Intent dismissIntent = new Intent(this, NotificationDismissReceiver.class);
        dismissIntent.putExtra("notificationId", notificationId);
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(this, 0, dismissIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);


        NotificationCompat.Builder builder = null;
        Notification notification =null;
//        Notification.notification = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new NotificationCompat.Builder(this,CHANNEL_ID)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setSmallIcon(R.drawable.baseline_notification_important_24)
                    .setAutoCancel(true)
                    .setContentIntent(intent1)
                    .setContentIntent((intent1))
                    .addAction(R.drawable.ic_dismiss,"Dismiss",dismissPendingIntent);
            notification = builder.build();

        }
        manager.notify(notificationId,notification);
    }

    private void createNotificationChannel(NotificationManager manager) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,"channelName",NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("My Description");
            channel.enableLights(true);
            channel.setLightColor(Color.WHITE);

            manager.createNotificationChannel(channel);
        }
    }
}