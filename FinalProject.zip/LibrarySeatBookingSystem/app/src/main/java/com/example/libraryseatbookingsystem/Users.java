package com.example.libraryseatbookingsystem;

import java.util.Date;

public class Users {
    String firstName, email,room,token;


    public Users() {
    }

    public Users(String firstName, String email, String room,String token) {
        this.firstName = firstName;
        this.email = email;
        this.room = room;
        this.token=token;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
