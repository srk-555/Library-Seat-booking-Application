package com.example.libraryseatbookingsystem;

import java.util.Date;

// to save data
public class Users_InRoom {
    String firstName, email, seatNo,token;

    Long startTime,endTime;

    public Users_InRoom() {

    }
    public Users_InRoom(String firstName, String email, String seatNo, Long startTime, Long endTime,String token ) {
        this.firstName = firstName;
        this.email = email;
        this.seatNo = seatNo;
        this.startTime=startTime;
        this.endTime=endTime;
        this.token = token;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getseatNo() {
        return seatNo;
    }

    public void setseatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }
    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}