package com.example.libraryseatbookingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class SettingsActivity extends AppCompatActivity {
    TextView name,email,howtouse;
    AppCompatButton logoutBtn;
    ImageView photo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        name=findViewById(R.id.name_settings);
        email =findViewById(R.id.email_settings);
        photo =findViewById(R.id.profile_photo_settings);
        logoutBtn=findViewById(R.id.logoutBtn);
        howtouse=findViewById(R.id.howtouse);

        name.setText(MainActivity.getActivityInstance().name);
        email.setText(MainActivity.getActivityInstance().email);
        Uri photoUrl = MainActivity.getActivityInstance().photoUrl;
        if(photoUrl != null) {
            String photo_string = photoUrl.toString();
            Glide.with(this)
                    .load(photo_string)
                    .circleCrop()
                    .into(photo);
        }
        else{
            String initials = getInitials(MainActivity.getActivityInstance().name);
            ColorGenerator generator = ColorGenerator.MATERIAL;
            int color = generator.getColor(MainActivity.getActivityInstance().email);
            TextDrawable drawable = TextDrawable.builder()
                    .beginConfig()
                    .width(80)
                    .height(80)
                    .endConfig()
                    .buildRound(initials, color);
            photo.setImageDrawable(drawable);
        }
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignOut();
            }
        });
        howtouse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(SettingsActivity.this,HowToUse.class);
                startActivity(intent);
            }
        });

    }

    private String getInitials(String name) {
        String[] splitName = name.split("\\s+");
        String firstName = splitName[0];
        return String.valueOf(firstName.charAt(0)).toUpperCase();
    }
    private void SignOut(){
        MainActivity.getActivityInstance().gsc.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                finish();
                Intent intent = new Intent(SettingsActivity.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }
}