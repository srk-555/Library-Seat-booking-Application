package com.example.libraryseatbookingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashSet;
import java.util.Set;

public class ViewRoomsActivity extends AppCompatActivity {
    TextView allUser, QuietUser2, GroupUser2, CasualUser2, QuietUser3, GroupUser3, CasualUser3;
    FirebaseDatabase fbDB, DB;
    DatabaseReference dbRef, c2Ref, c3Ref, g2Ref, g3Ref, q2Ref, q3Ref;
    int Total=0;
//    static Set<String> allUserHash = new HashSet<String>();
//    static Set<String> casualUserHash2 = new HashSet<String>();
//    static Set<String> quietUserHash2 = new HashSet<String>();
//    static Set<String> groupUserHash2 = new HashSet<String>();
//    static Set<String> casualUserHash3 = new HashSet<String>();
//    static Set<String> quietUserHash3 = new HashSet<String>();
//    static Set<String> groupUserHash3 = new HashSet<String>();

    ProgressBar progressBar, progressBarC2, progressBarC3, progressBarG2, progressBarG3, progressBarQ2, progressBarQ3;
    TextView progressText, progressTextC2, progressTextC3, progressTextG2, progressTextG3, progressTextQ2, progressTextQ3;

    int Quiet3=0,Quiet2=0,Casual3=0,Casual2=0,Group3=0,Group2=0;
//    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_rooms);

        progressBar = findViewById(R.id.progress_bar);
        progressBar.setMax(224);
        progressText = findViewById(R.id.progress_text);

        progressBarC2 = findViewById(R.id.progress_barC2);
        progressBarC2.setMax(32);
        progressTextC2 = findViewById(R.id.progress_textC2);
        progressBarC3 = findViewById(R.id.progress_barC3);
        progressBarC3.setMax(32);
        progressTextC3 = findViewById(R.id.progress_textC3);

        progressBarG2 = findViewById(R.id.progress_barG2);
        progressBarG2.setMax(32);
        progressTextG2 = findViewById(R.id.progress_textG2);
        progressBarG3 = findViewById(R.id.progress_barG3);
        progressBarG3.setMax(32);
        progressTextG3 = findViewById(R.id.progress_textG3);

        progressBarQ2 = findViewById(R.id.progress_barQ2);
        progressBarQ2.setMax(48);
        progressTextQ2 = findViewById(R.id.progress_textQ2);
        progressBarQ3 = findViewById(R.id.progress_barQ3);
        progressBarQ3.setMax(48);
        progressTextQ3 = findViewById(R.id.progress_textQ3);


        fbDB = FirebaseDatabase.getInstance();








        c2Ref = fbDB.getReference("Room/Casual2");
        c2Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                Long allCasualCount = snapshot.getChildrenCount();
                Log.e("count of all casual", "" + snapshot.getChildrenCount());
            for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                Long startTime1 = (Long) userSnapshot.child("startTime").getValue();
                 Long endTime1 = (Long) userSnapshot.child("endTime").getValue();
                 Long currentTime = System.currentTimeMillis();
                 if(isCurrentTimeInRange(currentTime,startTime1,endTime1))
                     Casual2++;

            }
                progressTextC2.setText("" + Casual2);
                progressBarC2.setProgress(Casual2);
                Total+=Casual2;
                progressText.setText("" + Total);
                progressBar.setProgress(Total);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(ViewRoomsActivity.this, "Fail to get data.C2Ref", Toast.LENGTH_SHORT).show();
                Log.e("Error Capacity", "Falied C2Ref");

            }
        });
        c3Ref = fbDB.getReference("Room/Casual3");
        c3Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Long allCasualCount3 = snapshot.getChildrenCount();
                Log.e("count of all  casual user", "" + snapshot.getChildrenCount());
               for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                   Long startTime1 = (Long) userSnapshot.child("startTime").getValue();
                   Long endTime1 = (Long) userSnapshot.child("endTime").getValue();
                   Long currentTime = System.currentTimeMillis();
                   if (isCurrentTimeInRange(currentTime, startTime1, endTime1))
                       Casual3++;

               }
                progressTextC3.setText("" + Casual3);
                progressBarC3.setProgress(Casual3);
                Total+=Casual3;
                progressText.setText("" + Total);
                progressBar.setProgress(Total);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(ViewRoomsActivity.this, "Fail to get data.C2Ref", Toast.LENGTH_SHORT).show();
                Log.e("Error Capacity", "Falied C2Ref");

            }
        });
        g2Ref = fbDB.getReference("Room/Group2");
        g2Ref.addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Long allCasualCount3 = snapshot.getChildrenCount();
                    Log.e("count of all  casual user", "" + snapshot.getChildrenCount());
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        Long startTime1 = (Long) userSnapshot.child("startTime").getValue();
                        Long endTime1 = (Long) userSnapshot.child("endTime").getValue();
                        Long currentTime = System.currentTimeMillis();
                        if (isCurrentTimeInRange(currentTime, startTime1, endTime1))
                            Group2++;

                    }
                    progressTextG2.setText("" + Group2);
                    progressBarG2.setProgress(Group2);
                    Total+=Group2;
                    progressText.setText("" + Total);
                    progressBar.setProgress(Total);
                }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(ViewRoomsActivity.this, "Fail to get data.g2Ref", Toast.LENGTH_SHORT).show();
                Log.e("Error Capacity", "Falied g2Ref");

            }
        });

        g3Ref = fbDB.getReference("Room/Group3");
        g3Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Long allGroupCount3 = snapshot.getChildrenCount();
                Log.e("count of all group user", "" + snapshot.getChildrenCount());
                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    Long startTime1 = (Long) userSnapshot.child("startTime").getValue();
                    Long endTime1 = (Long) userSnapshot.child("endTime").getValue();
                    Long currentTime = System.currentTimeMillis();
                    if (isCurrentTimeInRange(currentTime, startTime1, endTime1))
                        Group3++;

                }
                progressTextG3.setText("" + Group3);
                progressBarG3.setProgress(Group3);
                Total+=Group3;
                progressText.setText("" + Total);
                progressBar.setProgress(Total);
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(ViewRoomsActivity.this, "Fail to get data.g3Ref", Toast.LENGTH_SHORT).show();
                Log.e("Error Capacity", "Falied g3Ref");

            }
        });
        DB = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = DB.getReference("Room/" + "Quiet3");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    Long startTime1 = (Long) userSnapshot.child("startTime").getValue();
                    Long endTime1 = (Long) userSnapshot.child("endTime").getValue();
                    Long currentTime = System.currentTimeMillis();
                    if (isCurrentTimeInRange(currentTime, startTime1, endTime1))
                        Quiet3++;

                }
                progressTextQ3.setText("" + Quiet3);
                progressBarQ3.setProgress(Quiet3);
                Total+=Quiet3;
                progressText.setText("" + Total);
                progressBar.setProgress(Total);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        q2Ref = fbDB.getReference("Room/Quiet2");
        q2Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Long allQuietCount = snapshot.getChildrenCount();
                Log.e("count of all quiet user", "" + snapshot.getChildrenCount());
                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    Long startTime1 = (Long) userSnapshot.child("startTime").getValue();
                    Long endTime1 = (Long) userSnapshot.child("endTime").getValue();
                    Long currentTime = System.currentTimeMillis();
                    if (isCurrentTimeInRange(currentTime, startTime1, endTime1))
                        Quiet2++;

                }
                progressTextQ2.setText("" + Quiet2);
                progressBarQ2.setProgress(Quiet2);
                Total+=Quiet2;
                progressText.setText("" + Total);
                progressBar.setProgress(Total);
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(ViewRoomsActivity.this, "Fail to get data.q2Ref", Toast.LENGTH_SHORT).show();
                Log.e("Error Capacity", "Falied q2Ref");

            }
        });




    }
    public boolean isCurrentTimeInRange(long currentTime, long startTime, long endTime) {
        return currentTime >= startTime && currentTime <= endTime;
    }

}