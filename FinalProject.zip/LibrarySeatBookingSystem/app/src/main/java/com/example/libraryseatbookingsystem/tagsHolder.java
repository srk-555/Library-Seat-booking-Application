package com.example.libraryseatbookingsystem;

public class tagsHolder {
    int statusAvailable;
    int index;


    tagsHolder(int statusAvailable, int index){
        this.statusAvailable = statusAvailable;
        this.index = index;
    }

    public int getStatusAvailable() {
        return statusAvailable;
    }

    public int getIndex() {
        return index;
    }
}
