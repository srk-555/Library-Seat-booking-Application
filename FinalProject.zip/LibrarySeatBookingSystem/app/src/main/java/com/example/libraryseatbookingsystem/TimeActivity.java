package com.example.libraryseatbookingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class TimeActivity extends AppCompatActivity {
    private TimePicker startTimePicker;
    private TimePicker endTimePicker;
    Button timeOkbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        // Initialize the start and end time pickers
        startTimePicker = findViewById(R.id.start_time_picker);
        endTimePicker = findViewById(R.id.end_time_picker);
        timeOkbtn = findViewById(R.id.timeOk);

        Intent intent = getIntent();
        Class<?> Room = (Class<?>) intent.getSerializableExtra("RoomClass");
        boolean isBooking = intent.getBooleanExtra("isBooking",false);

        // Set default start time as current time
        Calendar defaultStartTime = Calendar.getInstance();
        startTimePicker.setHour(defaultStartTime.get(Calendar.HOUR_OF_DAY));
        startTimePicker.setMinute(defaultStartTime.get(Calendar.MINUTE));

// Set default end time as 3 hours from now
        Calendar defaultEndTime = Calendar.getInstance();
        defaultEndTime.add(Calendar.HOUR_OF_DAY, 3);
        endTimePicker.setHour(defaultEndTime.get(Calendar.HOUR_OF_DAY));
        endTimePicker.setMinute(defaultEndTime.get(Calendar.MINUTE));

//        // Set the time changed listener for both time pickers
//        TimePicker.OnTimeChangedListener timeChangedListener = new TimePicker.OnTimeChangedListener() {
//            @Override
//            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
//                // Round the minute to the nearest multiple of 30
//                int roundedMinute = Math.round(minute / 30f) * 30;
//                view.setMinute(roundedMinute);
//            }
//        };
//        startTimePicker.setOnTimeChangedListener(timeChangedListener);
//        endTimePicker.setOnTimeChangedListener(timeChangedListener);

        // Set the click listener for the Ok button
        timeOkbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the selected start time in milliseconds
                Calendar startTime = Calendar.getInstance();
                startTime.set(Calendar.HOUR_OF_DAY, startTimePicker.getHour());
                startTime.set(Calendar.MINUTE, startTimePicker.getMinute());
                startTime.set(Calendar.SECOND, 0);
                startTime.set(Calendar.MILLISECOND, 0);
                long startTimeInMillis = startTime.getTimeInMillis();

                // Get the selected end time in milliseconds
                Calendar endTime = Calendar.getInstance();
                endTime.set(Calendar.HOUR_OF_DAY, endTimePicker.getHour());
                endTime.set(Calendar.MINUTE, endTimePicker.getMinute());
                endTime.set(Calendar.SECOND, 0);
                endTime.set(Calendar.MILLISECOND, 0);
                long endTimeInMillis = endTime.getTimeInMillis();

                double durationHours = (double) (endTimeInMillis-startTimeInMillis) / 3600000;


                if(startTimeInMillis<System.currentTimeMillis())
                    Toast.makeText(TimeActivity.this, "Start Time cannot be less than the current Time!", Toast.LENGTH_SHORT).show();
                else if(startTimeInMillis>endTimeInMillis)
                    Toast.makeText(TimeActivity.this, "Start time cannot be greater than end time!", Toast.LENGTH_SHORT).show();
                else  if(durationHours>5.0)
                    Toast.makeText(TimeActivity.this, "Bookings longer than 5 hours are not allowed!", Toast.LENGTH_SHORT).show();
                else if(durationHours<1.0)
                    Toast.makeText(TimeActivity.this, "Bookings should of minimum one hour atleast!", Toast.LENGTH_SHORT).show();
                else {
                    // Create an intent to start the other activity
                    Intent intent = new Intent(TimeActivity.this, Room);
                    intent.putExtra("start_time", startTimeInMillis);
                    intent.putExtra("end_time", endTimeInMillis);
                    intent.putExtra("isBooking", isBooking);
                    startActivity(intent);
                }
            }
                // Code to send start and end times to another activity

        });
    }

}