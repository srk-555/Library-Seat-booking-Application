package com.example.libraryseatbookingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashSet;
import java.util.Set;

public class CasualRoomLayoutActivity extends AppCompatActivity implements MyFragmentListener {
    MeowBottomNavigation casualbottomNav;
    private static CasualRoomLayoutActivity INSTANCE;
    FirebaseDatabase db1;
    DatabaseReference SeatReference,UserReference;

    Set<String> casualSeatHash2 = new HashSet<String>();
    Set<String> casualSeatHash3 = new HashSet<String>();
    Bundle bundle5 = new Bundle();
    Bundle bundle6 = new Bundle();
    int initial_load=0;
    int currentId=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_casual_room_layout);
        INSTANCE = this;
        boolean isBooking = getIntent().getBooleanExtra("isBooking",false);
        bundle5.putBoolean("isBooking",isBooking);
        bundle6.putBoolean("isBooking",isBooking);

        Long start_time =getIntent().getLongExtra("start_time",0);
        Long end_time = getIntent().getLongExtra("end_time",0);
        bundle5.putLong("start_time",start_time);
        bundle5.putLong("end_time",end_time);
        bundle6.putLong("start_time",start_time);
        bundle6.putLong("end_time",end_time);


        db1 = FirebaseDatabase.getInstance();
        SeatReference = db1.getReference("Room/Casual2");



        SeatReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                casualSeatHash2 = new HashSet<String>();

//                Log.e("all User",snapshot.getChildren().toString());

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    Log.e("all User1",snapshot.getChildren().toString());
//                    Log.e("all User2",snapshot.getValue().toString());
//                    Log.e("all User3",userSnapshot.getChildren().toString());
//
//                    Log.e("all User4",userSnapshot.child("seatNo").getValue().toString());
                    if (System.currentTimeMillis() <= Long.parseLong(userSnapshot.child("endTime").getValue().toString())) {
                        if (Long.parseLong(userSnapshot.child("startTime").getValue().toString()) < end_time && Long.parseLong(userSnapshot.child("endTime").getValue().toString()) > start_time)
                            casualSeatHash2.add(userSnapshot.child("seatNo").getValue().toString());
                    } else {
                        String key = userSnapshot.getKey();
                        Log.e("KEY",key);
                        db1 = FirebaseDatabase.getInstance();
                        UserReference =db1.getReference("Users");
                        SeatReference = db1.getReference("Room/Casual2");
                        SeatReference.getRef().child(key).removeValue();
                        UserReference.getRef().child(key).removeValue();
                    }
                }

                Log.e("Seat no Casual Room Layout",casualSeatHash2.toString());
                bundle5.putString("clist",casualSeatHash2.toString());
                initial_load++;
                Log.e("Initial Load 2",""+initial_load);
                if(currentId==0)
                    casualbottomNav.show(2, true);
                if(initial_load>2) {
                    currentId=2;
                    reloadFragment();
                }
//                }


            }




            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(CasualRoomLayoutActivity.this, "Fail to get Seat data CasualRoom2", Toast.LENGTH_SHORT).show();
                Log.e("Error", "Fail to get Seat data CasualRoom2");

            }
        });

        db1 = FirebaseDatabase.getInstance();
        SeatReference = db1.getReference("Room/Casual3");

        SeatReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                casualSeatHash3 = new HashSet<String>();

//                Log.e("all User",snapshot.getChildren().toString());

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    Log.e("all User1",snapshot.getChildren().toString());
//                    Log.e("all User2",snapshot.getValue().toString());
//                    Log.e("all User3",userSnapshot.getChildren().toString());
//
//                    Log.e("all User4",userSnapshot.child("seatNo").getValue().toString());
                    if (System.currentTimeMillis() <= Long.parseLong(userSnapshot.child("endTime").getValue().toString())) {
                        if (Long.parseLong(userSnapshot.child("startTime").getValue().toString()) < end_time && Long.parseLong(userSnapshot.child("endTime").getValue().toString()) > start_time)
                            casualSeatHash3.add(userSnapshot.child("seatNo").getValue().toString());
                    }  else {
                        String key = userSnapshot.getKey();
                        Log.e("KEY",key);
                        db1 = FirebaseDatabase.getInstance();
                        UserReference =db1.getReference("Users");
                        SeatReference = db1.getReference("Room/Casual3");
                        SeatReference.getRef().child(key).removeValue();
                        UserReference.getRef().child(key).removeValue();
                    }
                }

                Log.e("Seat no Casual Room Layout",casualSeatHash3.toString());
                bundle6.putString("clist3",casualSeatHash3.toString());
                initial_load++;
                Log.e("Initial Load 3",""+initial_load);
                if(initial_load>2) {
                    currentId=3;
                    reloadFragment();
                }
//                }

            }




            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(CasualRoomLayoutActivity.this, "Fail to get Seat data CasualRoom3", Toast.LENGTH_SHORT).show();
                Log.e("Error", "Fail to get Seat data CasualRoom3");

            }
        });

        casualbottomNav = findViewById(R.id.casual_bottom_Nav);
        casualbottomNav.add(new MeowBottomNavigation.Model(2,R.drawable.two));
        casualbottomNav.add(new MeowBottomNavigation.Model(3,R.drawable.three));

        casualbottomNav.setOnShowListener(new MeowBottomNavigation.ShowListener() {
            @Override
            public void onShowItem(MeowBottomNavigation.Model item) {
//                if(currentId==0)
//                item.setId(2);
//                else
//                    item.setId(currentId);
                Fragment fragment = null;
                if(item.getId()==2){
                    fragment = new Casual2();
                    fragment.setArguments(bundle5);
                }

                else if(item.getId()==3){
                    fragment = new Casual3();
                    fragment.setArguments(bundle6);
                }
                loadFragment(fragment);
            }
        });
//        casualbottomNav.show(currentId, true);
        casualbottomNav.setOnClickMenuListener(new MeowBottomNavigation.ClickListener() {
            @Override
            public void onClickItem(MeowBottomNavigation.Model item) {
//                Toast.makeText(CasualRoomLayoutActivity.this,"You Clicked"+item.getId(),Toast.LENGTH_SHORT).show();
            }
        });

        casualbottomNav.setOnReselectListener(new MeowBottomNavigation.ReselectListener() {
            @Override
            public void onReselectItem(MeowBottomNavigation.Model item) {
//                Toast.makeText(CasualRoomLayoutActivity.this,"You Reselected"+item.getId(),Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void loadFragment(Fragment fragment) {
        if (getSupportFragmentManager().isDestroyed()) {
            return;
        }
//        getSupportFragmentManager().popBackStack();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.nav_host_fragment_container_3,fragment);
//        transaction.addToBackStack(null);
        transaction.commit();

    }

    private void reloadFragment() {
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_container_3);
        boolean isFloor2 = currentFragment instanceof Casual2;
        boolean isFloor3 = currentFragment instanceof Casual3;
        Log.e("Current Floor is  - ",""+currentFragment+"  "+isFloor2+"  "+isFloor3);

        if(currentId==2 && isFloor2){
            Log.e("Inside 2","here");
            Fragment fragment = new Casual2();
            fragment.setArguments(bundle5);
            loadFragment(fragment);
        }
        else if(currentId==3 && isFloor3){
            Log.e("Inside 3","here");
            Fragment fragment = new Casual3();
            fragment.setArguments(bundle6);
            loadFragment(fragment);
        }

    }



    public static CasualRoomLayoutActivity getInstance()
    {
        return INSTANCE;
    }

    @Override
    public void onSomeEvent() {
        onBackPressed();
    }
}