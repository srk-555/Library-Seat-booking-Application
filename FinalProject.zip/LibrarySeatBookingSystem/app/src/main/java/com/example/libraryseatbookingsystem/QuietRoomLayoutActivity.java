package com.example.libraryseatbookingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class QuietRoomLayoutActivity extends AppCompatActivity implements MyFragmentListener{
    private static QuietRoomLayoutActivity INSTANCE;
    MeowBottomNavigation quietbottomNav;
    FirebaseDatabase db1;
    DatabaseReference SeatReference, UserReference;

    Set<String> quietSeatHash2 = new HashSet<String>();
    Set<String> quietSeatHash3 = new HashSet<String>();
    Bundle bundle = new Bundle();
    Bundle bundle2 = new Bundle();
    int initial_load=0;
    int currentId=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiet_room_layout);
        INSTANCE = this;
        boolean isBooking = getIntent().getBooleanExtra("isBooking",false);
        bundle.putBoolean("isBooking",isBooking);
        bundle2.putBoolean("isBooking",isBooking);
        //to get occupied seat
        //getOccupiedSeat();
        Long start_time =getIntent().getLongExtra("start_time",0);
        Long end_time = getIntent().getLongExtra("end_time",0);
        bundle.putLong("start_time",start_time);
        bundle.putLong("end_time",end_time);
        bundle2.putLong("start_time",start_time);
        bundle2.putLong("end_time",end_time);
//
//        Bundle timeBundle =getIntent().getExtras();
//        Date startTime = (Date) timeBundle.getSerializable("startTime");
//        Date endTime = (Date) timeBundle.getSerializable("endTime");
//        bundle.putSerializable("startTime",startTime);
//        bundle.putSerializable("endTime",endTime);
//        bundle2.putSerializable("startTime",startTime);
//        bundle2.putSerializable("endTime",endTime);


        db1 = FirebaseDatabase.getInstance();
        SeatReference = db1.getReference("Room/Quiet2");



        SeatReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                quietSeatHash2 = new HashSet<String>();

//                Log.e("all User",snapshot.getChildren().toString());

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    Log.e("all User1",snapshot.getChildren().toString());
//                    Log.e("all User2",snapshot.getValue().toString());
//                    Log.e("all User3",userSnapshot.getChildren().toString());
//
//                    Log.e("all User4",userSnapshot.child("seatNo").getValue().toString());
                    if (System.currentTimeMillis() <= Long.parseLong(userSnapshot.child("endTime").getValue().toString())) {
                        if (Long.parseLong(userSnapshot.child("startTime").getValue().toString()) < end_time && Long.parseLong(userSnapshot.child("endTime").getValue().toString()) > start_time)
                            quietSeatHash2.add(userSnapshot.child("seatNo").getValue().toString());
                    } else {
                        String key = userSnapshot.getKey();
                        Log.e("KEY",key);
                        db1 = FirebaseDatabase.getInstance();
                        UserReference =db1.getReference("Users");
                        SeatReference = db1.getReference("Room/Quiet2");
                        SeatReference.getRef().child(key).removeValue();
                        UserReference.getRef().child(key).removeValue();
                    }
                }

                Log.e("Seat no Quiet Room Layout", quietSeatHash2.toString());
                bundle.putString("qlist", quietSeatHash2.toString());
                initial_load++;
                if(currentId==0)
                    quietbottomNav.show(2, true);
                if(initial_load>2) {
                    currentId=2;
                    reloadFragment();
                }


            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(QuietRoomLayoutActivity.this, "Fail to get Seat data QuietRoom2", Toast.LENGTH_SHORT).show();
                Log.e("Error", "Fail to get Seat data QuietRoom2");

            }
        });

        db1 = FirebaseDatabase.getInstance();
        SeatReference = db1.getReference("Room/Quiet3");

        SeatReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                quietSeatHash3 = new HashSet<String>();

//                Log.e("all User",snapshot.getChildren().toString());

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    Log.e("all User1",snapshot.getChildren().toString());
//                    Log.e("all User2",snapshot.getValue().toString());
//                    Log.e("all User3",userSnapshot.getChildren().toString());
//
//                    Log.e("all User4",userSnapshot.child("seatNo").getValue().toString());
                    if (System.currentTimeMillis() <= Long.parseLong(userSnapshot.child("endTime").getValue().toString())) {
                        if (Long.parseLong(userSnapshot.child("startTime").getValue().toString()) < end_time && Long.parseLong(userSnapshot.child("endTime").getValue().toString()) > start_time)
                            quietSeatHash3.add(userSnapshot.child("seatNo").getValue().toString());
                    } else {
                        String key = userSnapshot.getKey();
                        Log.e("KEY",key);
                        db1 = FirebaseDatabase.getInstance();
                        UserReference =db1.getReference("Users");
                        SeatReference = db1.getReference("Room/Quiet3");
                        SeatReference.getRef().child(key).removeValue();
                        UserReference.getRef().child(key).removeValue();
                    }
                }

                Log.e("Seat no Quiet Room Layout", quietSeatHash3.toString());
                bundle2.putString("qlist3", quietSeatHash3.toString());
                initial_load++;
                Log.e("Initial Load 3",""+initial_load);
                if(initial_load>2) {
                    currentId=3;
                    reloadFragment();
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(QuietRoomLayoutActivity.this, "Fail to get Seat data QuietRoom2", Toast.LENGTH_SHORT).show();
                Log.e("Error", "Fail to get Seat data QuietRoom2");

            }
        });
        //Log.e("Seat no Quiet Room Layout Outside",quietSeatHash2.toString());


        quietbottomNav = findViewById(R.id.quietbottomNav);
        quietbottomNav.add(new MeowBottomNavigation.Model(2, R.drawable.two));
        quietbottomNav.add(new MeowBottomNavigation.Model(3, R.drawable.three));

        quietbottomNav.setOnShowListener(new MeowBottomNavigation.ShowListener() {
            @Override
            public void onShowItem(MeowBottomNavigation.Model item) {


// set Fragmentclass Arguments
                //Fragmentclass fragobj = new Fragmentclass();
                //fragobj.setArguments(bundle);
                Fragment fragment = null;
                if (item.getId() == 2) {
                    fragment = new Quiet2();
                    fragment.setArguments(bundle);
                } else if (item.getId() == 3) {
                    fragment = new Quiet3();
                    fragment.setArguments(bundle2);
                }
                loadFragment(fragment);
            }
        });
//        if(count==1)
//        quietbottomNav.show(2,true);


        quietbottomNav.setOnClickMenuListener(new MeowBottomNavigation.ClickListener() {
            @Override
            public void onClickItem(MeowBottomNavigation.Model item) {
//                Toast.makeText(QuietRoomLayoutActivity.this, "You Clicked" + item.getId(), Toast.LENGTH_SHORT).show();
            }
        });

        quietbottomNav.setOnReselectListener(new MeowBottomNavigation.ReselectListener() {
            @Override
            public void onReselectItem(MeowBottomNavigation.Model item) {
//                Toast.makeText(QuietRoomLayoutActivity.this, "You Reselected" + item.getId(), Toast.LENGTH_SHORT).show();
            }
        });
        //set count to two item
//        bottomNav.setCount(1,"5");

    }
    private void reloadFragment() {
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_container_1);
        boolean isFloor2 = currentFragment instanceof Quiet2;
        boolean isFloor3 = currentFragment instanceof Quiet3;
        Log.e("Current Floor is  - ",""+currentFragment+"  "+isFloor2+"  "+isFloor3);

        if(currentId==2 && isFloor2){
            Log.e("Inside 2","here");
            Fragment fragment = new Quiet2();
            fragment.setArguments(bundle);
            loadFragment(fragment);
        }
        else if(currentId==3 && isFloor3){
            Log.e("Inside 3","here");
            Fragment fragment = new Quiet3();
            fragment.setArguments(bundle2);
            loadFragment(fragment);
        }

    }

    private void loadFragment(Fragment fragment) {
        if (getSupportFragmentManager().isDestroyed()) {
            return;
        }
//        getSupportFragmentManager().popBackStack();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.nav_host_fragment_container_1,fragment);
//        transaction.addToBackStack(null);
        transaction.commit();

    }

    public static QuietRoomLayoutActivity getInstance() {
        return INSTANCE;
    }

    private void getOccupiedSeat() {

    }

    @Override
    public void onSomeEvent() {
        onBackPressed();
    }
}