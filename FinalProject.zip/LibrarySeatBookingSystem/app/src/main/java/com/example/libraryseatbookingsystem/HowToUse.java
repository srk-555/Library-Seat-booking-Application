package com.example.libraryseatbookingsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.widget.TextView;

public class HowToUse extends AppCompatActivity {
    private CardView cardView1, cardView2, cardView3;
    private TextView cardViewTitle1, cardViewTitle2, cardViewTitle3;
    private boolean isCard1Expanded = false;
    private boolean isCard2Expanded = false;
    private boolean isCard3Expanded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_use);

        cardView1 = findViewById(R.id.card_view_1);
        cardView2 = findViewById(R.id.card_view_2);
        cardView3 = findViewById(R.id.card_view_3);
        cardViewTitle1 = findViewById(R.id.card_view_title_1);
        cardViewTitle2 = findViewById(R.id.card_view_title_2);
        cardViewTitle3 = findViewById(R.id.card_view_title_3);

        // Set the titles for the card views
        cardViewTitle1.setText("Alert");
        cardViewTitle2.setText("Crowd");
        cardViewTitle3.setText("Issues");

        // Set a click listener for each card view
        cardView1.setOnClickListener(v -> {
            isCard1Expanded = !isCard1Expanded;
            if (isCard1Expanded) {
                cardViewTitle1.setText("Any user who has a booking in Quiet Study can send a notification to the people present in the room at the given time if there are disturbances in the Quiet Study Room\"");
            } else {
                cardViewTitle1.setText("Alert");
            }
        });

        cardView2.setOnClickListener(v -> {
            isCard2Expanded = !isCard2Expanded;
            if (isCard2Expanded) {
                cardViewTitle2.setText("A user can see the count of people present in each room at a particular time.");
            } else {
                cardViewTitle2.setText("Crowd");
            }
        });

        cardView3.setOnClickListener(v -> {
            isCard3Expanded = !isCard3Expanded;
            if (isCard3Expanded) {
                cardViewTitle3.setText("A user can send mail to the library admin if he/she has any library related issues or concerns");
            } else {
                cardViewTitle3.setText("Issues");
            }
        });
    }
}