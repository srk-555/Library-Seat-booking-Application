package com.example.libraryseatbookingsystem;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Quiet3 extends Fragment implements View.OnClickListener{
    private MyFragmentListener mListener;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MyFragmentListener) {
            mListener = (MyFragmentListener) context;
        }
    }

    ViewGroup layout;
    Button QuietBook3;
    boolean flag3 = false;

    String seats ="TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "__________/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "__________/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/"
            + "TB_ATTB_AT/";

//    String seats ="TB___CCCC_/"
//            + "TB___TTTT_/"
//            + "TB___DDDD_/"
//            + "__________/"
//            + "_____CCCC_/"
//            + "TB___TTTT_/"
//            + "TB___DDDD_/"
//            + "__________/"
//            + "TB___CCCC_/"
//            + "_____TTTT_/"
//            + "TB___DDDD_/"
//            + "__________/"
//            + "TB___CCCC_/"
//            + "TB___TTTT_/"
//            + "_____DDDD_/"
//            + "__________/"
//            + "TB___CCCC_/"
//            + "TB___TTTT_/"
//            + "TB___DDDD_/";

//    String seats ="TB_ATTB_AT/"
//            + "TB_ATTB_AT/"
//            + "TB_ATTB_AT/"
//            + "TB_ATTB_AT/"
//            + "__________/"
//            + "TB_ATTB_AT/"
//            + "TB_ATTB_AT/"
//            + "TB_ATTB_AT/"
//            + "TB_ATTB_AT/";

    String row = "_A_B__C_D_/";

    int numSeats = 0;
    String gate = "____G_____";

    List<Integer> reserved_Seats  = new ArrayList<>();

    Button GroupBook;
    List<TextView> seatViewList = new ArrayList<>();
    int seatSize = 80;
    int seatGaping = 8;

    int A_STATUS_AVAILABLE = 11;

    int B_STATUS_AVAILABLE = 12;
    int C_STATUS_AVAILABLE = 13;
    int D_STATUS_AVAILABLE = 14;
    int A_STATUS_BOOKED = 21;

    int B_STATUS_BOOKED = 22;
    int C_STATUS_BOOKED = 23;
    int D_STATUS_BOOKED = 24;
    int STATUS_RESERVED = 3;
    String selectedIds = "";

    FirebaseDatabase db,db1;
    DatabaseReference RoomReference,UserReference,SeatReference;
    String SeatNo;
    int count =0;
    Long startTime,endTime;
    Set<Integer> quietSeatHash3 = new HashSet<Integer>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Bundle bundle2 = getArguments();
        boolean isBooking = bundle2.getBoolean("isBooking");
        Long start_time = bundle2.getLong("start_time");
        Long end_time = bundle2.getLong("end_time");


        if (bundle2 != null) {
            String strtext = bundle2.getString("qlist3");
            Log.e("qlist in frag-3",""+strtext);
            if(!strtext.equals("[]")){
            String[] strParts = strtext.substring(1, strtext.length() - 1).split(",");

            List<String> listParts = Arrays.asList(strParts);

            for (int i = 0; i < listParts.size(); i++) {
                quietSeatHash3.add(Integer.valueOf(listParts.get(i).trim()));
            }}
        }


        View fragview = inflater.inflate(R.layout.fragment_quiet3, container, false);
//Log.e("Count Before",count.toString());
        //to get occupied seat
        //getOccupiedSeat();


        layout = fragview.findViewById(R.id.QuitelayoutSeat_3);

        seats = "/" + seats;

        LinearLayout layoutSeat = new LinearLayout(getContext());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutSeat.setOrientation(LinearLayout.VERTICAL);
        layoutSeat.setLayoutParams(params);
        layoutSeat.setPadding(8 * seatGaping, 8 * seatGaping, 8 * seatGaping, 8 * seatGaping);
        layout.addView(layoutSeat);

        LinearLayout layout = null;


        for (int index = 0; index < seats.length(); index++) {
            if (seats.charAt(index) == '/') {
                layout = new LinearLayout(getContext());
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layoutSeat.addView(layout);
            } else if (seats.charAt(index) == 'A') {
                count++;
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
                if (quietSeatHash3.contains(count)) {
                    view.setBackgroundResource(R.drawable.a_booked);
                    view.setTag(A_STATUS_BOOKED);
                } else {
                    view.setBackgroundResource(R.drawable.a_unbooked);
                    view.setTag(A_STATUS_AVAILABLE);
                    view.setOnClickListener(this);
                }
                layout.addView(view);
                seatViewList.add(view);
//                view.setOnClickListener(this);
            } else if (seats.charAt(index) == 'B') {
                count++;
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
//                view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15);
//                view.setTextColor(Color.BLACK);
                if (quietSeatHash3.contains(count)) {
                    view.setBackgroundResource(R.drawable.b_booked);
                    view.setTag(B_STATUS_BOOKED);
                } else {
                    view.setBackgroundResource(R.drawable.b_unbooked);
                    view.setTag(B_STATUS_AVAILABLE);
                    view.setOnClickListener(this);
                }
                layout.addView(view);
                seatViewList.add(view);
//                view.setOnClickListener(this);
            } else if (seats.charAt(index) == 'C') {
                count++;
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
//                view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15);
//                view.setTextColor(Color.BLACK);
                if (quietSeatHash3.contains(count)) {
                    view.setBackgroundResource(R.drawable.c_booked);
                    view.setTag(C_STATUS_BOOKED);
                } else {
                    view.setBackgroundResource(R.drawable.c_unbooked);
                    view.setTag(C_STATUS_AVAILABLE);
                    view.setOnClickListener(this);
                }
                layout.addView(view);
                seatViewList.add(view);
//                view.setOnClickListener(this);
            } else if (seats.charAt(index) == 'D') {
                count++;
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
                if (quietSeatHash3.contains(count)) {
                    view.setBackgroundResource(R.drawable.c_booked);
                    view.setTag(C_STATUS_BOOKED);
                } else {
                    view.setBackgroundResource(R.drawable.c_unbooked);
                    view.setTag(C_STATUS_AVAILABLE);
                    view.setOnClickListener(this);
                }
                layout.addView(view);
                seatViewList.add(view);
//                view.setOnClickListener(this);
            } else if (seats.charAt(index) == 'R') {
//                count++;
//                TextView view = new TextView(this);
//                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
//                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
//                view.setLayoutParams(layoutParams);
//                view.setPadding(0, 0, 0, 2 * seatGaping);
//                view.setId(count);
//                view.setGravity(Gravity.CENTER);
//                view.setBackgroundResource(R.drawable.ic_seats_reserved);
//                view.setText(count + "");
//                view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
//                view.setTextColor(Color.WHITE);
//                view.setTag(STATUS_RESERVED);
//                layout.addView(view);
//                seatViewList.add(view);
//                view.setOnClickListener(this);
            } else if (seats.charAt(index) == 'T') {
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setGravity(Gravity.CENTER);
                view.setBackgroundResource(R.drawable.square12);
                view.setTag(STATUS_RESERVED);
                view.setClickable(false);
                layout.addView(view);
                seatViewList.add(view);
            } else if (seats.charAt(index) == '_') {
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setBackgroundColor(Color.TRANSPARENT);
                view.setText("");
                view.setClickable(false);
                layout.addView(view);
            }
        }

        for (int i = 0; i < row.length(); i++) {
            if (row.charAt(i) == '/') {
                layout = new LinearLayout(getContext());
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layoutSeat.addView(layout);
            } else if (row.charAt(i) == '_') {
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setBackgroundColor(Color.TRANSPARENT);
                view.setText("");
                layout.addView(view);
            } else {
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setGravity(Gravity.CENTER);
                view.setText(String.valueOf(row.charAt(i)));
                view.setTextSize(20);
                view.setVisibility(View.VISIBLE);
                view.setTag(STATUS_RESERVED);
                layout.addView(view);
            }
        }
        for (int i = 0; i < gate.length(); i++) {
            if (gate.charAt(i) == '_') {
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setBackgroundColor(Color.TRANSPARENT);
                view.setText("__");
                layout.addView(view);
            } else if (gate.charAt(i) == 'G') {
                TextView view = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setGravity(Gravity.CENTER);
                view.setBackgroundResource(R.drawable.doubledoor);
                view.setTextSize(10);
                view.setVisibility(View.VISIBLE);
                view.setTag(STATUS_RESERVED);
                layout.addView(view);
            }
        }

        QuietBook3 = fragview.findViewById(R.id.QuietBook3);
        QuietBook3.setOnClickListener(view -> {
            if(!isBooking) {
                Log.e("list", String.valueOf(seatViewList.size()));
                Log.e("is seatview list empty", String.valueOf(seatViewList.isEmpty()));
                if (seatViewList != null && !seatViewList.isEmpty() && reserved_Seats.size()!=0) {
//                SeatNo = String.valueOf(reserved_Seats.get(0));
                    Log.e("Seat no database", SeatNo);
//                    Calendar calendar = Calendar.getInstance();
//                    startTime = calendar.getTimeInMillis();
//                    calendar.add(Calendar.HOUR_OF_DAY, +1);
//                    endTime = calendar.getTimeInMillis();
                    addToDataBase(SeatNo, start_time, end_time);
//                    Toast.makeText(getContext(), "Your seat has been booked", Toast.LENGTH_SHORT).show();
                    showSuccessPopup();

                } else {
                    Toast.makeText(getContext(), "Please select atleast one seat", Toast.LENGTH_SHORT).show();
                }
            }
            else{
                Toast.makeText(getContext(), "You can only book one seat at a time", Toast.LENGTH_SHORT).show();
            }
        });
        return fragview;

    }


    private void addToDataBase(String SeatNo,Long StartTime,Long EndTime) {
        Object [] UserDetail = MainActivity.getActivityInstance().getData();
//        Log.e("userDetail",UserDetail.toString());
        String name= String.valueOf(UserDetail[0]);
        String email= String.valueOf(UserDetail[1]);
        Log.e("name",""+UserDetail[0]);
        Log.e("email",""+UserDetail[1]);
        int index = email.indexOf('@'); // find the index of the '@' symbol
        String username = email.substring(0, index);
        Log.e("current Time",""+StartTime+""+EndTime);
        try {
            db = FirebaseDatabase.getInstance();
            FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
                if (!TextUtils.isEmpty(token)) {
                    RoomReference = db.getReference("Room/Quiet3");
                    Users_InRoom usersInRoom = new Users_InRoom(name, email, SeatNo, StartTime, EndTime,token);

                    RoomReference.child(username).setValue(usersInRoom);
                    //Log.e("TOKEN COMPLETE", "This is the token : " + tokenValue[0]);
                    Users user = new Users(name, email, "Quiet3",token);
                    UserReference = db.getReference("Users");
                    UserReference.child(username).setValue(user);
                    Log.e("TOKEN", "retrieve token successful : " + token);
                } else{
                    Log.e("TOKEN ERROR", "token should not be null...");
                }    });

//            Users_InRoom usersInRoom = new Users_InRoom(name, email,SeatNo,StartTime,EndTime);
//            db = FirebaseDatabase.getInstance();
//            RoomReference = db.getReference("Room/Quiet3");
//            RoomReference.child(username).setValue(usersInRoom);
//
//            Users user = new Users(name,email,"Quiet3");
//            UserReference = db.getReference("Users");
//            UserReference.child(username).setValue(user);
        }
        catch (Exception e){
            Log.e("Error",""+e);
            Log.i("Error Name",""+name);
            Log.i("Error Email",""+email);
//            Toast.makeText(getContext(),"Name and Email is null",Toast.LENGTH_LONG).show();
        }
    }



    @Override
    public void onClick(View view) {
        if ((int) view.getTag() == A_STATUS_AVAILABLE && (SeatNo == null || SeatNo.equals(String.valueOf(view.getId()))) ) {
            if (selectedIds.contains(view.getId() + ",")) {
                selectedIds = selectedIds.replace(+view.getId() + ",", "");
                Log.e("seat number unbooked", String.valueOf(view.getId()));
                view.setBackgroundResource(R.drawable.a_unbooked);
                reserved_Seats.remove(Integer.valueOf(view.getId()));
                SeatNo=null;
            } else {
                selectedIds = selectedIds + view.getId() + ",";
                Log.e("seat number booked", String.valueOf(view.getId()));
                SeatNo = String.valueOf(view.getId());
                view.setBackgroundResource(R.drawable.a_selected);
                reserved_Seats.add(view.getId());
            }
        }
        else if ((int) view.getTag() == B_STATUS_AVAILABLE && (SeatNo == null || SeatNo.equals(String.valueOf(view.getId()))) ) {
            if (selectedIds.contains(view.getId() + ",")) {
                selectedIds = selectedIds.replace(+view.getId() + ",", "");
                Log.e("seat number unbooked", String.valueOf(view.getId()));
                view.setBackgroundResource(R.drawable.b_unbooked);
                reserved_Seats.remove(Integer.valueOf(view.getId()));
                SeatNo=null;
            } else {
//                Toast.makeText(this, "hey", Toast.LENGTH_SHORT).show();
                selectedIds = selectedIds + view.getId() + ",";
                Log.e("seat number booked", String.valueOf(view.getId()));
//                Toast.makeText(this, "hi", Toast.LENGTH_SHORT).show();
                view.setBackgroundResource(R.drawable.b_selected);
                SeatNo = String.valueOf(view.getId());
                reserved_Seats.add(view.getId());
//                Toast.makeText(this, "hi again", Toast.LENGTH_SHORT).show();
            }
        }
        else if ((int) view.getTag() == C_STATUS_AVAILABLE && (SeatNo == null || SeatNo.equals(String.valueOf(view.getId()))) ) {
            if (selectedIds.contains(view.getId() + ",")) {
                selectedIds = selectedIds.replace(+view.getId() + ",", "");
                Log.e("seat number unbooked", String.valueOf(view.getId()));
                view.setBackgroundResource(R.drawable.c_unbooked);
                reserved_Seats.remove(Integer.valueOf(view.getId()));
                SeatNo=null;
            } else {
//                Toast.makeText(this, "hey", Toast.LENGTH_SHORT).show();
                selectedIds = selectedIds + view.getId() + ",";
                Log.e("seat number booked", String.valueOf(view.getId()));
//                Toast.makeText(this, "hi", Toast.LENGTH_SHORT).show();
                view.setBackgroundResource(R.drawable.c_selected);
                SeatNo = String.valueOf(view.getId());
                reserved_Seats.add(view.getId());
//                Toast.makeText(this, "hi again", Toast.LENGTH_SHORT).show();
            }
        }
        else if ((int) view.getTag() == D_STATUS_AVAILABLE && (SeatNo == null || SeatNo.equals(String.valueOf(view.getId()))) ) {
            if (selectedIds.contains(view.getId() + ",")) {
                selectedIds = selectedIds.replace(+view.getId() + ",", "");
                Log.e("seat number unbooked", String.valueOf(view.getId()));
                view.setBackgroundResource(R.drawable.d_unbooked);
                reserved_Seats.remove(Integer.valueOf(view.getId()));
                SeatNo=null;
            } else {
//                Toast.makeText(this, "hey", Toast.LENGTH_SHORT).show();
                selectedIds = selectedIds + view.getId() + ",";
                Log.e("seat number booked", String.valueOf(view.getId()));
//                Toast.makeText(this, "hi", Toast.LENGTH_SHORT).show();
                view.setBackgroundResource(R.drawable.d_selected);
                SeatNo = String.valueOf(view.getId());
                reserved_Seats.add(view.getId());
//                Toast.makeText(this, "hi again", Toast.LENGTH_SHORT).show();
            }
        }
        else if ((int) view.getTag() == A_STATUS_BOOKED) {
//            Toast.makeText(getContext(), "Seat " + view.getId() + " is Booked", Toast.LENGTH_SHORT).show();
        } else if ((int) view.getTag() == STATUS_RESERVED) {
//            Toast.makeText(getContext(), "Seat " + view.getId() + " is Reserved", Toast.LENGTH_SHORT).show();
        }

        Log.e("seat size", String.valueOf(reserved_Seats.size()));
//        if (reserved_Seats.size() == 0){
////            QuietRoomLayoutActivity.getInstance().quietbottomNav.setVisibility(View.VISIBLE);
////            QuietBook3.setVisibility(View.GONE);
//            flag3 = true;
//        }
//        else {
////            QuietRoomLayoutActivity.getInstance().quietbottomNav.setVisibility(View.GONE);
////            QuietBook3.setVisibility(View.VISIBLE);
//            flag3 =false;
//        }
    }

    private void showSuccessPopup() {
        // Inflate the popup layout
        View popupView = getLayoutInflater().inflate(R.layout.popup_success, null);

        // Find the success icon and set the animation
        ImageView successIcon = popupView.findViewById(R.id.success_icon);
        Animation successAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.success_animation);
        successIcon.startAnimation(successAnimation);

        // Find the success message and set the text
        TextView successMessage = popupView.findViewById(R.id.success_message);
        successMessage.setText("Booking Confirmed!");

        // Create the popup dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setView(popupView);

        // Show the popup dialog
        AlertDialog dialog = builder.create();
        dialog.show();

        // Add listener to animation
        successAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                // Animation finished, navigate to menu fragment
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
//                        ((MenuActivity) getActivity()).navigateToMenuFragment();
//                        getActivity().onBackPressed();
                        dialog.dismiss();
                        if (mListener!= null){
                            mListener.onSomeEvent();
                        }
//                        QuietRoomLayoutActivity.getInstance().onBackPressed();
                    }
                }, 1000);// dismiss the dialog once navigation is triggered
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
    }
}