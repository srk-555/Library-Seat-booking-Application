








package com.example.libraryseatbookingsystem;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MenuActivity extends AppCompatActivity {
    public static final String SERVER_KEY = "AAAAJ2rLq4Q:APA91bGTECKRQGo0PcD93uq_V2beABiyVkMx9Z0dRHPhylzyMf827a45lHQ5wiRlC1Skvy0Dwbj1caSsW6qLcqfd-UIw4xry8F7J4BjltaMDFR8m0qLi3YcJXxL9s242TP0FSotNV1_-";

    private static final String TAG = "AlertActivity";
    private static final String FCM_API_URL = "https://fcm.googleapis.com/fcm/send";

    private boolean doubleBackToExitPressedOnce = false;
    Long startTime1, endTime1;
    Boolean flag = false;
    static Set<String> tokenList = new HashSet<String>();
    private Handler mHandler = new Handler();

    GoogleSignInOptions gso;
    GoogleSignInClient gsc;

    Button quietBtn, casualBtn, groupBtn, unBookBtn;
    ImageButton crowdBtn, alertBtn, issueBtn;
    LinearLayout crowdLnr, alertLnr, settingsLnr, issueLnr;
    AppCompatImageButton settingsBtn, refreshBtn;
    ImageView profilePhoto;

    TextView nameTxt, BookingDetail, floorNo, room, start, end, seat;
    CardView seatBooked, noSeat;
    LinearLayout hiddenView;
    ConstraintLayout cardLayout;
    ImageView arrow;
    String email, name;
    Uri photoUrl;

    FirebaseDatabase db;
    DatabaseReference UserReference, SeatReference;
    String seatNo = "0";
    static String roomName;
    String username;
    String AlertroomName;
    Calendar startTime = null;
    Calendar endTime = null;
    int starthour = 0, startminute = 0, endhour = 0, endminute = 0;
    static Set<String> allUserList = new HashSet<String>();

    static Set<String> qList2 = new HashSet<String>();
    private static MenuActivity instance;
    Object value, seatValue;
    Set<String> quietSeatHash2 = new HashSet<String>();
    Boolean isBooking = false;
    Long userIStart;

    Long userIEnd;
    Long currentTime ;
    static Set<String> userTokenList = new HashSet<String>();
    boolean canSend = false;
    int checkSend = 0;
    String RoomNo="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Get the intent that started this activity
        Intent intent = getIntent();
        if (intent.hasExtra("displayPopup")) {
            Log.e("notify", "this runs ");
            View dialogView = LayoutInflater.from(MenuActivity.this).inflate(R.layout.initial_popup, null);

            // Create the dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this)
                    .setView(dialogView)
                    .setCancelable(false); // Prevent dismiss on outside touch or back press

            AlertDialog dialog = builder.create();

            Button okButton = dialogView.findViewById(R.id.dialog_ok_button);
            okButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            // Show the dialog
            dialog.show();
        }


//        db = FirebaseDatabase.getInstance();
//        SeatReference = db.getReference("Room/Quiet2");
//
//        SeatReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    qList2.add(userSnapshot.child("seatNo").getValue().toString());
//                }Log.e("Seat Menu Activity",qList2.toString());
//            }
//
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(MenuActivity.this, "Fail to get Seat data QuietRoom2", Toast.LENGTH_SHORT).show();
//                Log.e("Error", "Fail to get Seat data QuietRoom2");
//
//            }
//        });
//
//        Log.e("seat on Menu",""+qList2.toString());
//


        instance = this;
        quietBtn = findViewById(R.id.quietBtn);
        casualBtn = findViewById(R.id.casualBtn);
        groupBtn = findViewById(R.id.groupBtn);
        crowdBtn = findViewById(R.id.occupancyBtn);
        seatBooked = findViewById(R.id.seatInfo);
        hiddenView = findViewById(R.id.hidden_view);
        floorNo = findViewById(R.id.floor_no);
        room = findViewById(R.id.room_name);
        start = findViewById(R.id.start_time);
        end = findViewById(R.id.end_time);
        seat = findViewById(R.id.seat_no);
        arrow = findViewById(R.id.arrow);
        nameTxt = findViewById(R.id.userName);
        profilePhoto = findViewById(R.id.profile_photo);
        settingsBtn = findViewById(R.id.settingsBtn);
        issueBtn = findViewById(R.id.issueBtn);
        unBookBtn = findViewById(R.id.unBook);
        noSeat = findViewById(R.id.noSeat);
        cardLayout = findViewById(R.id.fixed_layout);
        refreshBtn = findViewById(R.id.refresh_btn);
        alertBtn = findViewById(R.id.alertBtn);
        issueLnr = findViewById(R.id.issueLnr);
        alertLnr = findViewById(R.id.alertLnr);
        crowdLnr = findViewById(R.id.crowdLnr);
        settingsLnr = findViewById(R.id.settingsLnr);


        //Checking if the user is already signedIn
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null) {
            email = account.getEmail();
            name = account.getDisplayName();
            photoUrl = account.getPhotoUrl();
            int index = email.indexOf('@'); // find the index of the '@' symbol
            String username = email.substring(0, index);
            //MenuFragment.getInstance().BookingDetail.setText("hello");

            db = FirebaseDatabase.getInstance();
            UserReference = db.getReference("Users");
            UserReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    value=snapshot.child(username).getValue();
                    //Toast.makeText(MainActivity.this, "on Data changed user", Toast.LENGTH_SHORT).show();

                    if (value!=null){
                        //Log.e("Snapshot main",snapshot.getChildren().toString());
                        RoomNo=snapshot.child(username).child("room").getValue().toString();
                        //Toast.makeText(MainActivity.this, "1"+seatNo, Toast.LENGTH_SHORT).show();
                        //MenuFragment.getInstance().BookingDetail.setText("hello"+snapshot.child(username));
                        //Log.e("room number",seatNo);
                        //Toast.makeText(MainActivity.this, "3"+RoomNo, Toast.LENGTH_SHORT).show();
                        SeatReference = db.getReference("Room/"+RoomNo);
                        //Log.e("Seat In Main",SeatReference.toString());
                        //Toast.makeText(INSTANCE, "Seat "+SeatReference, Toast.LENGTH_LONG).show();
                        SeatReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot1) {
                                //Toast.makeText(MainActivity.this, "on Data changed seat", Toast.LENGTH_SHORT).show();
                                //Toast.makeText(MainActivity.this, "seat"+snapshot1.child(username), Toast.LENGTH_LONG).show();

                                Log.e("Snapshot Seat", snapshot1.child(username).toString());
                                seatValue = snapshot1.child(username).getValue();

                                if (seatValue!=null){
                                    Long starttimestamp= (Long) snapshot1.child(username).child("startTime").getValue();
                                    Long endtimestamp= (Long) snapshot1.child(username).child("endTime").getValue();

                                    startTime=Calendar.getInstance();
                                    endTime=Calendar.getInstance();

                                    startTime.setTimeInMillis(starttimestamp);
                                    endTime.setTimeInMillis(endtimestamp);
                                    starthour = startTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
                                    startminute = startTime.get(Calendar.MINUTE);

                                    endhour = endTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
                                    endminute = endTime.get(Calendar.MINUTE);

                                    MenuActivity.getInstance().seat.setText(seatNo);
                                    MenuActivity.getInstance().start.setText(starthour+ " : " + startminute);
                                    MenuActivity.getInstance().end.setText(endhour+ " : " + endminute);


                                    //Log.e("Snapshot main",snapshot.getChildren().toString());
                                    seatNo = snapshot1.child(username).child("seatNo").getValue().toString();
                                    //Toast.makeText(MainActivity.this, "seat 1 "+seatNo, Toast.LENGTH_SHORT).show();

                                    String desc = "";
                                    if (RoomNo.endsWith("3")) {
                                        desc = RoomNo.substring(0, RoomNo.length() - 1) + " Study";
                                        MenuActivity.getInstance().floorNo.setText("Floor No: " + String.valueOf(3));
                                    } else if (RoomNo.endsWith("2")) {
                                        desc = RoomNo.substring(0, RoomNo.length() - 1) + " Study";
                                        MenuActivity.getInstance().floorNo.setText("Floor No: " + String.valueOf(2));
                                    }
                                    MenuActivity.getInstance().seat.setText(seatNo);
                                    MenuActivity.getInstance().room.setText(desc);
                                    MenuActivity.getInstance().unBookBtn.setVisibility(View.VISIBLE);
                                    MenuActivity.getInstance().cardLayout.setVisibility(View.VISIBLE);
                                    MenuActivity.getInstance().noSeat.setVisibility(View.GONE);
                                    MenuActivity.getInstance().unBookBtn.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            //Toast.makeText(this, "Unbooked Tapped"+RoomNo, Toast.LENGTH_SHORT).show();
                                            //unBookSeat(username,RoomNo);
                                            snapshot.getRef().child(username).removeValue();
                                            snapshot1.getRef().child(username).removeValue();
                                            MenuActivity.getInstance().cardLayout.setVisibility(View.GONE);
                                            MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);
                                            MenuActivity.getInstance().unBookBtn.setVisibility(View.GONE);
                                            MenuActivity.getInstance().hiddenView.setVisibility(View.GONE);
//                                            Toast.makeText(MenuActivity.this, "Unbooked Tapped Main"+RoomNo, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                                else if (seatValue == null) {
                                    //Log.e("Snapshot main",snapshot.getChildren().toString());
                                    //    Toast.makeText(MainActivity.this, "seat 2 "+seatNo, Toast.LENGTH_SHORT).show();
                                }

                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                    else if (value==null) {
                        //Log.e("Snapshot main",snapshot.getChildren().toString());
                        //Toast.makeText(MainActivity.this, "2"+seatNo, Toast.LENGTH_SHORT).show();
                        MenuActivity.getInstance().cardLayout.setVisibility(View.GONE);
                        MenuActivity.getInstance().unBookBtn.setVisibility(View.GONE);
                        MenuActivity.getInstance().hiddenView.setVisibility(View.GONE);
                        MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);

                    }
                    MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }


        Object[] UserDetail = MainActivity.getActivityInstance().getData();
//        Log.e("userDetail",UserDetail.toString());
        String name = String.valueOf(UserDetail[0]);
        String email = String.valueOf(UserDetail[1]);
        Log.e("name", "" + UserDetail[0]);
        Log.e("email", "" + UserDetail[1]);
        int index = email.indexOf('@'); // find the index of the '@' symbol
        username = email.substring(0, index);
        ;
        // Log an error message and return the view
//        username=username.replaceAll("\\d", "");
        nameTxt.setText(name);
        Log.e("Menu Activity Name", "MainActivity is not null" + MainActivity.getActivityInstance().name);

        addBookingDetail();

        if (photoUrl != null) {
            String photo = photoUrl.toString();
            Glide.with(this)
                    .load(photo)
                    .circleCrop()
                    .into(profilePhoto);
        } else {
            String initials = getInitials(name);
            ColorGenerator generator = ColorGenerator.MATERIAL;
            int color = generator.getColor(email);
            TextDrawable drawable = TextDrawable.builder()
                    .beginConfig()
                    .width(100)
                    .height(100)
                    .endConfig()
                    .buildRound(initials, color);
            profilePhoto.setImageDrawable(drawable);
        }
        quietBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                if (!isBooking) {
                Intent intent = new Intent(MenuActivity.this, TimeActivity.class);
                intent.putExtra("RoomClass", QuietRoomLayoutActivity.class);
                intent.putExtra("isBooking", isBooking);
                intent.putExtra("AlertRoomName", AlertroomName);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // add this line
                startActivity(intent);


//                loadActivity(QuietRoomLayoutActivity.class);
//                } else {
//                    Toast.makeText(MenuActivity.this, "You Can Book Only One Seat", Toast.LENGTH_SHORT).show();
//                }
            }
        });

        groupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, TimeActivity.class);
                intent.putExtra("RoomClass", GroupRoomLayoutActivity.class);
                intent.putExtra("isBooking", isBooking);
                intent.putExtra("AlertRoomName", AlertroomName);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // add this line
                startActivity(intent);
            }
        });

        casualBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, TimeActivity.class);
                intent.putExtra("RoomClass", CasualRoomLayoutActivity.class);
                intent.putExtra("isBooking", isBooking);
                intent.putExtra("AlertRoomName", AlertroomName);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // add this line
                startActivity(intent);
            }
        });


        crowdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadActivity(ViewRoomsActivity.class);
            }
        });
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadActivity(SettingsActivity.class);
            }
        });
        issueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = "admin-library@iiitd.ac.in, library@iiitd.ac.in"; // replace with your email address
                String subject = "Issue Regarding - ";
                String body = "Description of the issue...";

                Uri uri = Uri.parse("mailto:" + email + "?subject=" + subject + "&body=" + body);

                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, uri);
                emailIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(emailIntent, "Send email via"));
            }
        });
        alertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag = true;
                if (flag) {

                    db = FirebaseDatabase.getInstance();
                    UserReference = db.getReference("Users");
                    tokenList = new HashSet<>();
                    UserReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            value = snapshot.child(username).getValue();
                            if (value != null) {
                                roomName = snapshot.child(username).child("room").getValue().toString();
                                if (roomName.equals("Quiet2") || roomName.equals("Quiet3")) {

                                    SeatReference = db.getReference("Room/" + roomName);
                                    //userSnapshot.child("endTime").getValue().toString();
                                    Log.e("seat", SeatReference.toString());
                                    SeatReference.addListenerForSingleValueEvent(new ValueEventListener() {

                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
                                            tokenList = new HashSet<>();
                                            if (snapshot1.exists()) {
                                                startTime1 = (Long) snapshot1.child(username).child("startTime").getValue();
                                                endTime1 = (Long) snapshot1.child(username).child("endTime").getValue();
                                                currentTime = System.currentTimeMillis();

//                                                Long startTime = Long.valueOf(360000);
//                                                Long endTime = Long.valueOf(370000);
                                                Log.e("startTime", startTime1.toString());
                                                Log.e("snapshot", snapshot1.toString());
                                                Log.e("endtime", endTime1.toString());
                                                if (isCurrentTimeInRange(currentTime, startTime1, endTime1)) {
                                                    flag = false;
                                                    for (DataSnapshot userSnapshot : snapshot1.getChildren()) {
                                                        Log.e("snap",""+userSnapshot);
                                                        userIStart = (Long) userSnapshot.child("startTime").getValue();
                                                        userIEnd = (Long) userSnapshot.child("endTime").getValue();
                                                        if (isCurrentTimeInRange(currentTime, userIStart, userIEnd) && !userSnapshot.child("email").getValue().toString().equals(email)) {
                                                            tokenList.add(userSnapshot.child("token").getValue().toString());
                                                        }
                                                    }
                                                    Log.e("token list-shr", "" + tokenList);
                                                    View dialogView = LayoutInflater.from(MenuActivity.this).inflate(R.layout.alert_pop_up, null);

                                                    // Create the dialog
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this)
                                                            .setView(dialogView)
                                                            .setCancelable(false); // Prevent dismiss on outside touch or back press

                                                    AlertDialog dialog = builder.create();

//                            // Set click listeners for cancel and OK buttons
                                                    Button cancelButton = dialogView.findViewById(R.id.dialog_cancel_button);
                                                    cancelButton.setOnClickListener(new View.OnClickListener() {
                                                        @Override
                                                        public void onClick(View v) {
                                                            // Dismiss the dialog
                                                            dialog.dismiss();
                                                            flag = false;
                                                        }
                                                    });
                                                    Button okButton = dialogView.findViewById(R.id.dialog_ok_button);
                                                    okButton.setOnClickListener(new View.OnClickListener() {
                                                        @Override
                                                        public void onClick(View v) {
                                                            performAlertNotificationOperation(tokenList);
                                                            // Perform your desired functionality here
                                                            // ...

                                                            // Dismiss the dialog
                                                            dialog.dismiss();
                                                            flag = false;
                                                        }
                                                    });

                                                    // Show the dialog
                                                    dialog.show();

                                                } else{
                                                    //Log.e("error");
                                                    Toast.makeText(MenuActivity.this, "You can use this only during your Booking Duration", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });

                                } else {
                                    Toast.makeText(MenuActivity.this, "This feature can be used only for Quiet Room bookings", Toast.LENGTH_SHORT).show();
                                    flag = false;
                                }

                            } else {
                                Toast.makeText(MenuActivity.this, "You need to have a Booking to use this feature", Toast.LENGTH_SHORT).show();
                                flag = false;
                            }
                            flag = false;

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });

        crowdLnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadActivity(ViewRoomsActivity.class);
            }
        });
        settingsLnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadActivity(SettingsActivity.class);
            }
        });
        issueLnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = "admin-library@iiitd.ac.in, library@iiitd.ac.in"; // replace with your email address
                String subject = "Issue Regarding - ";
                String body = "Description of the issue...";

                Uri uri = Uri.parse("mailto:" + email + "?subject=" + subject + "&body=" + body);

                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, uri);
                emailIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(emailIntent, "Send email via"));
            }
        });
        alertLnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag = true;
                if (flag) {

                    db = FirebaseDatabase.getInstance();
                    UserReference = db.getReference("Users");
                    tokenList = new HashSet<>();
                    UserReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            value = snapshot.child(username).getValue();
                            if (value != null) {
                                roomName = snapshot.child(username).child("room").getValue().toString();
                                if (roomName.equals("Quiet2") || roomName.equals("Quiet3")) {

                                    SeatReference = db.getReference("Room/" + roomName);
                                    //userSnapshot.child("endTime").getValue().toString();
                                    Log.e("seat", SeatReference.toString());
                                    SeatReference.addListenerForSingleValueEvent(new ValueEventListener() {

                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
                                            tokenList = new HashSet<>();
                                            if (snapshot1.exists()) {
                                                startTime1 = (Long) snapshot1.child(username).child("startTime").getValue();
                                                endTime1 = (Long) snapshot1.child(username).child("endTime").getValue();
                                                currentTime = System.currentTimeMillis();

//                                                Long startTime = Long.valueOf(360000);
//                                                Long endTime = Long.valueOf(370000);
                                                Log.e("startTime", startTime1.toString());
                                                Log.e("snapshot", snapshot1.toString());
                                                Log.e("endtime", endTime1.toString());
                                                if (isCurrentTimeInRange(currentTime, startTime1, endTime1)) {
                                                    flag = false;
                                                    for (DataSnapshot userSnapshot : snapshot1.getChildren()) {
                                                        Log.e("snap",""+userSnapshot);
                                                        userIStart = (Long) userSnapshot.child("startTime").getValue();
                                                        userIEnd = (Long) userSnapshot.child("endTime").getValue();
                                                        if (isCurrentTimeInRange(currentTime, userIStart, userIEnd) && !userSnapshot.child("email").getValue().toString().equals(email)) {
                                                            tokenList.add(userSnapshot.child("token").getValue().toString());
                                                        }
                                                    }
                                                    Log.e("token list-shr", "" + tokenList);
                                                    View dialogView = LayoutInflater.from(MenuActivity.this).inflate(R.layout.alert_pop_up, null);

                                                    // Create the dialog
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this)
                                                            .setView(dialogView)
                                                            .setCancelable(false); // Prevent dismiss on outside touch or back press

                                                    AlertDialog dialog = builder.create();

//                            // Set click listeners for cancel and OK buttons
                                                    Button cancelButton = dialogView.findViewById(R.id.dialog_cancel_button);
                                                    cancelButton.setOnClickListener(new View.OnClickListener() {
                                                        @Override
                                                        public void onClick(View v) {
                                                            // Dismiss the dialog
                                                            dialog.dismiss();
                                                            flag = false;
                                                        }
                                                    });
                                                    Button okButton = dialogView.findViewById(R.id.dialog_ok_button);
                                                    okButton.setOnClickListener(new View.OnClickListener() {
                                                        @Override
                                                        public void onClick(View v) {
                                                            performAlertNotificationOperation(tokenList);
                                                            // Perform your desired functionality here
                                                            // ...

                                                            // Dismiss the dialog
                                                            dialog.dismiss();
                                                            flag = false;
                                                        }
                                                    });

                                                    // Show the dialog
                                                    dialog.show();

                                                } else{
                                                    //Log.e("error");
                                                    Toast.makeText(MenuActivity.this, "You can use this only during your Booking Duration", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });

                                } else {
                                    Toast.makeText(MenuActivity.this, "This feature can be used only for Quiet Room bookings", Toast.LENGTH_SHORT).show();
                                    flag = false;
                                }

                            } else {
                                Toast.makeText(MenuActivity.this, "You need to have a Booking to use this feature", Toast.LENGTH_SHORT).show();
                                flag = false;
                            }
                            flag = false;

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });
        cardLayout.setOnClickListener(v -> {
            // If the CardView is already expanded, set its visibility
            // to gone and change the expand less icon to expand more.
            if (hiddenView.getVisibility() == View.VISIBLE) {
                // The transition of the hiddenView is carried out by the TransitionManager class.
                // Here we use an object of the AutoTransition Class to create a default transition
                TransitionManager.beginDelayedTransition(cardLayout, new AutoTransition());
                hiddenView.setVisibility(View.GONE);
                arrow.setImageResource(R.drawable.arrow_down_ic);
                Log.e("Arrow down", "Arrow 1");
//                arrow.setImageResource(R.drawable.ic_baseline_expand_more_24);
            }

            // If the CardView is not expanded, set its visibility to
            // visible and change the expand more icon to expand less.
            else {
                TransitionManager.beginDelayedTransition(cardLayout, new AutoTransition());
                hiddenView.setVisibility(View.VISIBLE);
                arrow.setImageResource(R.drawable.arrow_up_ic);
                Log.e("Arrow up", "Arrow 1");
//                arrow.setImageResource(R.drawable.ic_baseline_expand_less_24);
            }
        });

        db = FirebaseDatabase.getInstance();
        UserReference = db.getReference("Users");
        UserReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                value = snapshot.child(username).getValue();
                if (value != null) {
                    AlertroomName = snapshot.child(username).child("room").getValue().toString();
//                    Toast.makeText(MenuActivity.this, "user found", Toast.LENGTH_SHORT).show();
                    isBooking = true;
                    noSeat.setVisibility(View.GONE);
                    seatBooked.setVisibility(View.VISIBLE);
                    cardLayout.setVisibility(View.VISIBLE);
                } else {
//                    Toast.makeText(MenuActivity.this, "user not found", Toast.LENGTH_SHORT).show();
                    isBooking = false;
                    noSeat.setVisibility(View.VISIBLE);
                    seatBooked.setVisibility(View.GONE);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//        detailsCard.setOnClickListener(v -> {
//            // If the CardView is already expanded, set its visibility
//            // to gone and change the expand less icon to expand more.
//            if (hiddenView.getVisibility() == View.VISIBLE) {
//                // The transition of the hiddenView is carried out by the TransitionManager class.
//                // Here we use an object of the AutoTransition Class to create a default transition
//                TransitionManager.beginDelayedTransition(detailsCard, new AutoTransition());
//                hiddenView.setVisibility(View.GONE);
//                arrow.setImageResource(R.drawable.arrow_down_ic);
////                arrow.setImageResource(R.drawable.ic_baseline_expand_more_24);
//            }
//
//            // If the CardView is not expanded, set its visibility to
//            // visible and change the expand more icon to expand less.
//            else {
//                TransitionManager.beginDelayedTransition(detailsCard, new AutoTransition());
//                hiddenView.setVisibility(View.VISIBLE);
//                arrow.setImageResource(R.drawable.arrow_up_ic);
////                arrow.setImageResource(R.drawable.ic_baseline_expand_less_24);
//            }
//        });
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(refreshBtn, "rotation", 0f, 360f);
                rotationAnimator.setDuration(2000);
                rotationAnimator.start();
                refreshDetail();
            }
        });


    }


    private void performAlertNotificationOperation(Set<String> utokenList) {
        Log.e(" Alert Token List in Notification Operation - ", "" + utokenList);
        Toast.makeText(MenuActivity.this, "Notifying " + utokenList.size() + " student(s) around you to maintain silence", Toast.LENGTH_SHORT).show();
        String title = "Silence in " + AlertroomName;
        String message = "Please maintain silence in " + AlertroomName + ". Students around you are getting disturbed.";

        for (String token : utokenList) {
            sendNotification(token, title, message);
        }
    }


    private void sendNotification(String token, String title, String message) {
        RequestQueue queue = Volley.newRequestQueue(this);

        // Construct JSON body for POST request
        JSONObject notificationBody = new JSONObject();
        try {
            notificationBody.put("to", token);

            JSONObject data = new JSONObject();
            data.put("title", title);
            data.put("message", message);

            notificationBody.put("data", data);
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON body", e);
        }

        // Construct POST request
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                FCM_API_URL,
                notificationBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("Notification sent successfully", "" + response);
//                        Log.i(TAG, "Notification sent successfully: " + response);
                        Toast.makeText(MenuActivity.this, "Notification sent successfully", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorResponse = new String(error.networkResponse.data, StandardCharsets.UTF_8);
                        Log.e(TAG, "Error sending notification: " + errorResponse, error);
//                        Toast.makeText(MenuActivity.this, "Error sending notification: " + errorResponse, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", "key=" + SERVER_KEY);
                return headers;
            }
        };

        // Add POST request to Volley queue
        queue.add(request);
    }

//    private void getAlertToken() {
//
//        currentTime= System.currentTimeMillis();
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference UserRef = database.getReference("Room/"+AlertroomName+"/"+username);
//        UserRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                if (dataSnapshot.exists()) {
//                    Long startTime = (Long) dataSnapshot.child("startTime").getValue();
//                    Long endTime = (Long) dataSnapshot.child("endTime").getValue();
//                    if (isCurrentTimeInRange(currentTime, startTime, endTime))
//                        canSend = true;
//                    else {
//                        canSend = false;
//                    }
//                }
//                checkSend++;
//            }
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                Log.e(TAG, "onCancelled", databaseError.toException());
//            }
//        });
//
//        DatabaseReference roomRef = database.getReference("Room").child(AlertroomName);
//        roomRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot personSnapshot : snapshot.getChildren()) {
//                    userIStart = (Long) personSnapshot.child("startTime").getValue();
//                    userIEnd = (Long) personSnapshot.child("endTime").getValue();
//                    if (isCurrentTimeInRange(currentTime, userIStart, userIEnd) && personSnapshot.child("email").getValue().toString() != email ) { //&& personSnapshot.child("email").getValue().toString() != email
//                        userTokenList.add(personSnapshot.child("token").getValue().toString());
//                    }
//
//                    // Do something with the values (e.g. store in a list or array)
//                    // ...
//                }
//                Log.e("UserTokenList inside the OnDataChange - ",""+userTokenList);
//                checkSend++;
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                // Handle the error
//                // ...
//            }
//        });
//
//      nSend==true)
//           performAlertNotificationOperation(); if(ca
//       else Toast.makeText(MenuActivity.this, "You can use this only during your Booking Duration", Toast.LENGTH_SHORT).show();
//
//    }

    public boolean isCurrentTimeInRange(long currentTime, long startTime, long endTime) {
        return currentTime >= startTime && currentTime <= endTime;
    }

    private void refreshDetail() {
        Object[] UserDetail = MainActivity.getActivityInstance().getData();
//        Log.e("userDetail",UserDetail.toString());
        String name = String.valueOf(UserDetail[0]);
        String email = String.valueOf(UserDetail[1]);
        int index = email.indexOf('@'); // find the index of the '@' symbol
        String username = email.substring(0, index);
        ;
        db = FirebaseDatabase.getInstance();
        UserReference = db.getReference("Users");
        UserReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                value = snapshot.child(username).getValue();
                if (value != null) {
                    roomName = snapshot.child(username).child("room").getValue().toString();
                    SeatReference = db.getReference("Room/" + roomName);
                    Log.e("seat", SeatReference.toString());
                    SeatReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot1) {

                            Long endtimestamp = (Long) snapshot1.child(username).child("endTime").getValue();
                            if (endtimestamp != null) {
                                if (System.currentTimeMillis() <= Long.parseLong(endtimestamp.toString())) {

                                } else {
                                    SeatReference.getRef().child(username).removeValue();
                                    UserReference.getRef().child(username).removeValue();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
//        finish();
//        startActivity(getIntent());
    }

    private void loadActivity(Class<?> activityClass) {

        Intent intent = new Intent(MenuActivity.this, activityClass);
        intent.putExtra("isBooking", isBooking);
        intent.putExtra("AlertRoomName", AlertroomName);
        startActivity(intent);

    }

    private String getInitials(String name) {
        String[] splitName = name.split("\\s+");
        String firstName = splitName[0];
        return String.valueOf(firstName.charAt(0)).toUpperCase();
    }

    public static MenuActivity getInstance() {
        return instance;
    }

//    public String getUsername() {
//        Object[] UserDetail = MainActivity.getActivityInstance().getData();
////        Log.e("userDetail",UserDetail.toString());
//        String name = String.valueOf(UserDetail[0]);
//        String email = String.valueOf(UserDetail[1]);
//        Log.e("name", "" + UserDetail[0]);
//        Log.e("email", "" + UserDetail[1]);
//        int index = email.indexOf('@'); // find the index of the '@' symbol
//        String username = email.substring(0, index);
//        return username;
//    }

    public void addBookingDetail() {
        Object[] UserDetail = MainActivity.getActivityInstance().getData();
//        Log.e("userDetail",UserDetail.toString());
        String name = String.valueOf(UserDetail[0]);
        String email = String.valueOf(UserDetail[1]);
        Log.e("name", "" + UserDetail[0]);
        Log.e("email", "" + UserDetail[1]);
        int index = email.indexOf('@'); // find the index of the '@' symbol
        String username = email.substring(0, index);

        db = FirebaseDatabase.getInstance();
        UserReference = db.getReference("Users");

        UserReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Long allUserCount = snapshot.getChildrenCount();
                //Log.e("Children",snapshot.toString());
                Log.e("count of all user in menu", "" + snapshot.getChildrenCount());
                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    allUserList.add(userSnapshot.getKey());
                }

                Log.e("User List menu", "" + allUserList);
                if (allUserCount == 0 || allUserList.isEmpty()) {

                    allUserList.clear();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(MenuActivity.this, "error in fetching user list", Toast.LENGTH_SHORT).show();
            }
        });
        Log.e("UserList", "" + allUserList);


        if (allUserList.contains(username)) {
            Log.e("ho", "ho");
            db = FirebaseDatabase.getInstance();
            UserReference = db.getReference("Users");

            UserReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    value = snapshot.child(username).getValue();
                    if (value != null) {
                        roomName = snapshot.child(username).child("room").getValue().toString();
                        String desc;
                        if (roomName.endsWith("3")) {
                            desc = roomName.substring(0, roomName.length() - 1) + " Study";
                            floorNo.setText("Floor No: " + String.valueOf(3));

                        } else if (roomName.endsWith("2")) {
                            desc = roomName.substring(0, roomName.length() - 1) + " Study";
                            floorNo.setText("Floor No: " + String.valueOf(2));
                        } else {
                            desc = roomName;
                        }
                        room.setText(desc);
                        SeatReference = db.getReference("Room/" + roomName);
                        Log.e("seat", SeatReference.toString());
                        SeatReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot1) {
                                Log.e("seat", snapshot1.child(username).toString());
                                seatValue = snapshot1.child(username).getValue();
                                if (seatValue != null) {
                                    DataSnapshot seatSnanpshot = snapshot1.child(username).child("seatNo");
                                    //Log.e("seatsnapshot",seatSnanpshot.getValue().toString());
                                    seatNo = seatSnanpshot.getValue().toString();

                                    Long starttimestamp = (Long) snapshot1.child(username).child("startTime").getValue();
                                    Long endtimestamp = (Long) snapshot1.child(username).child("endTime").getValue();

                                    startTime = Calendar.getInstance();
                                    endTime = Calendar.getInstance();

                                    startTime.setTimeInMillis(starttimestamp);
                                    endTime.setTimeInMillis(endtimestamp);
                                    starthour = startTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
                                    startminute = startTime.get(Calendar.MINUTE);

                                    endhour = endTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
                                    endminute = endTime.get(Calendar.MINUTE);
                                    seat.setText(seatNo);
                                    start.setText(starthour + " : " + startminute);
                                    end.setText(endhour + " : " + endminute);

//                                    BookingDetail.setText(desc+" \n Seat number: "+seatNo+"\n"+starthour+":"+startminute+"   "+endhour+":"+endminute);
                                    unBookBtn.setVisibility(View.VISIBLE);
                                    seatBooked.setVisibility(View.VISIBLE);
                                    arrow.setImageResource(R.drawable.arrow_down_ic);
                                    Log.e("Arrow down", "Arrow 2");
                                    unBookBtn.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            snapshot.getRef().child(username).removeValue();
                                            snapshot1.getRef().child(username).removeValue();
//                                            BookingDetail.setText("You have not booked your seat");
                                            noSeat.setVisibility(View.VISIBLE);
                                            unBookBtn.setVisibility(View.GONE);
                                            cardLayout.setVisibility(View.GONE);
                                            hiddenView.setVisibility(View.GONE);
//                                            Toast.makeText(MenuActivity.this, "Unbooked Tapped Menu" + roomName, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
//                        Log.e("starttime",""+starthour+""+);
//                        Log.e("starttime",snapshot.child(username).child("endTime").getValue().toString());
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
//                                Toast.makeText(MenuActivity.this, "Fail to get Seat data ", Toast.LENGTH_SHORT).show();
                                Log.e("Error", "Fail to get Seat data ");
                            }
                        });

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
//                    Toast.makeText(MenuActivity.this, "Fail to get userData", Toast.LENGTH_SHORT).show();
                    Log.e("Error", "Fail to get userData");
                }
            });

        } else {
            noSeat.setVisibility(View.VISIBLE);
            cardLayout.setVisibility(View.GONE);
            hiddenView.setVisibility(View.GONE);

        }
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }


        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 4000); // Delay for 4 seconds
    }

}

















//package com.example.libraryseatbookingsystem;
//
//import static android.content.ContentValues.TAG;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AlertDialog;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.AppCompatImageButton;
//import androidx.cardview.widget.CardView;
//import androidx.constraintlayout.widget.ConstraintLayout;
//import androidx.fragment.app.Fragment;
//import androidx.fragment.app.FragmentManager;
//import androidx.fragment.app.FragmentTransaction;
//
//import android.animation.ObjectAnimator;
//import android.content.Intent;
//import android.net.Uri;
//import android.os.Bundle;
//import android.os.Handler;
//import android.transition.AutoTransition;
//import android.transition.TransitionManager;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.Button;
//import android.widget.ImageButton;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.amulyakhare.textdrawable.TextDrawable;
//import com.amulyakhare.textdrawable.util.ColorGenerator;
//import com.android.volley.Request;
//import com.android.volley.RequestQueue;
//import com.android.volley.Response;
//import com.android.volley.VolleyError;
//import com.android.volley.toolbox.JsonObjectRequest;
//import com.android.volley.toolbox.Volley;
//import com.bumptech.glide.Glide;
//import com.google.android.gms.auth.api.signin.GoogleSignIn;
//import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
//import com.google.android.gms.auth.api.signin.GoogleSignInClient;
//import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.nio.charset.StandardCharsets;
//import java.util.Calendar;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Map;
//import java.util.Set;
//
//public class MenuActivity extends AppCompatActivity {
//    public static  final String SERVER_KEY = "AAAAJ2rLq4Q:APA91bGTECKRQGo0PcD93uq_V2beABiyVkMx9Z0dRHPhylzyMf827a45lHQ5wiRlC1Skvy0Dwbj1caSsW6qLcqfd-UIw4xry8F7J4BjltaMDFR8m0qLi3YcJXxL9s242TP0FSotNV1_-";
//
//    private static final String TAG = "AlertActivity";
//    private static final String FCM_API_URL = "https://fcm.googleapis.com/fcm/send";
//
//    private boolean doubleBackToExitPressedOnce = false;
//    Boolean flag = false;
//    static Set<String> tokenList = new HashSet<String>();
//    private Handler mHandler = new Handler();
//
//    GoogleSignInOptions gso;
//    GoogleSignInClient gsc;
//
//    Button quietBtn, casualBtn, groupBtn, unBookBtn;
//    LinearLayout crowdBtn,alertBtn, settingsBtn, issueBtn;
//    AppCompatImageButton refreshBtn;
//    ImageView profilePhoto;
//
//    TextView nameTxt, BookingDetail, floorNo, room, start, end, seat;
//    CardView  seatBooked, noSeat;
//    LinearLayout hiddenView;
//    ConstraintLayout cardLayout;
//    ImageView arrow;
//    String email, name;
//    Uri photoUrl;
//
//    FirebaseDatabase db;
//    DatabaseReference UserReference, SeatReference;
//    String seatNo = "0";
//    static String roomName;
//    String username;
//    String AlertroomName;
//    Calendar startTime = null;
//    Calendar endTime = null;
//    int starthour = 0, startminute = 0, endhour = 0, endminute = 0;
//    static Set<String> allUserList = new HashSet<String>();
//
//    static Set<String> qList2 = new HashSet<String>();
//    private static MenuActivity instance;
//    Object value, seatValue;
//    Set<String> quietSeatHash2 = new HashSet<String>();
//    Boolean isBooking = false;
//    Long userIStart;
//
//    Long userIEnd;
//    Long currentTime;
//    String RoomNo="1";
//    static Set<String> userTokenList = new HashSet<String>();
//    boolean canSend = false;
//    int checkSend=0;
//    Long endTime1,startTime1;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_menu);
//
//        // Get the intent that started this activity
//        Intent intent = getIntent();
//        if (intent.hasExtra("displayPopup")) {
//            Log.e("notify", "this runs ");
//            View dialogView = LayoutInflater.from(MenuActivity.this).inflate(R.layout.initial_popup, null);
//
//            // Create the dialog
//            AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this)
//                    .setView(dialogView)
//                    .setCancelable(false); // Prevent dismiss on outside touch or back press
//
//            AlertDialog dialog = builder.create();
//
//            Button okButton = dialogView.findViewById(R.id.dialog_ok_button);
//            okButton.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    dialog.dismiss();
//                }
//            });
//
//            // Show the dialog
//            dialog.show();
//        }
//
//
////        db = FirebaseDatabase.getInstance();
////        SeatReference = db.getReference("Room/Quiet2");
////
////        SeatReference.addValueEventListener(new ValueEventListener() {
////            @Override
////            public void onDataChange(@NonNull DataSnapshot snapshot) {
////
////                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
////                    qList2.add(userSnapshot.child("seatNo").getValue().toString());
////                }Log.e("Seat Menu Activity",qList2.toString());
////            }
////
////
////            @Override
////            public void onCancelled(@NonNull DatabaseError error) {
////                Toast.makeText(MenuActivity.this, "Fail to get Seat data QuietRoom2", Toast.LENGTH_SHORT).show();
////                Log.e("Error", "Fail to get Seat data QuietRoom2");
////
////            }
////        });
////
////        Log.e("seat on Menu",""+qList2.toString());
////
//
//
//
//
//        instance = this;
//        quietBtn = findViewById(R.id.quietBtn);
//        casualBtn = findViewById(R.id.casualBtn);
//        groupBtn = findViewById(R.id.groupBtn);
//        crowdBtn = findViewById(R.id.occupancyBtn);
//        seatBooked = findViewById(R.id.seatInfo);
//        hiddenView = findViewById(R.id.hidden_view);
//        floorNo = findViewById(R.id.floor_no);
//        room = findViewById(R.id.room_name);
//        start = findViewById(R.id.start_time);
//        end = findViewById(R.id.end_time);
//        seat = findViewById(R.id.seat_no);
//        arrow = findViewById(R.id.arrow);
//        nameTxt = findViewById(R.id.userName);
//        profilePhoto = findViewById(R.id.profile_photo);
//        settingsBtn = findViewById(R.id.settingsBtn);
//        issueBtn = findViewById(R.id.issueBtn);
//        unBookBtn = findViewById(R.id.unBook);
//        noSeat = findViewById(R.id.noSeat);
//        cardLayout = findViewById(R.id.fixed_layout);
//        refreshBtn = findViewById(R.id.refresh_btn);
//        alertBtn = findViewById(R.id.alertBtn);
//
//
//        //Checking if the user is already signedIn
//        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
//        if (account != null) {
//            email = account.getEmail();
//            name = account.getDisplayName();
//            photoUrl = account.getPhotoUrl();
//            int index = email.indexOf('@'); // find the index of the '@' symbol
//            String username = email.substring(0, index);
//            //MenuFragment.getInstance().BookingDetail.setText("hello");
//
//            db = FirebaseDatabase.getInstance();
//            UserReference = db.getReference("Users");
//            UserReference.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    value=snapshot.child(username).getValue();
//                    //Toast.makeText(MainActivity.this, "on Data changed user", Toast.LENGTH_SHORT).show();
//
//                    if (value!=null){
//                        //Log.e("Snapshot main",snapshot.getChildren().toString());
//                        RoomNo=snapshot.child(username).child("room").getValue().toString();
//                        //Toast.makeText(MainActivity.this, "1"+seatNo, Toast.LENGTH_SHORT).show();
//                        //MenuFragment.getInstance().BookingDetail.setText("hello"+snapshot.child(username));
//                        //Log.e("room number",seatNo);
//                        //Toast.makeText(MainActivity.this, "3"+RoomNo, Toast.LENGTH_SHORT).show();
//                        SeatReference = db.getReference("Room/"+RoomNo);
//                        //Log.e("Seat In Main",SeatReference.toString());
//                        //Toast.makeText(INSTANCE, "Seat "+SeatReference, Toast.LENGTH_LONG).show();
//                        SeatReference.addValueEventListener(new ValueEventListener() {
//                            @Override
//                            public void onDataChange(@NonNull DataSnapshot snapshot1) {
//                                //Toast.makeText(MainActivity.this, "on Data changed seat", Toast.LENGTH_SHORT).show();
//                                //Toast.makeText(MainActivity.this, "seat"+snapshot1.child(username), Toast.LENGTH_LONG).show();
//
//                                Log.e("Snapshot Seat", snapshot1.child(username).toString());
//                                seatValue = snapshot1.child(username).getValue();
//
//                                if (seatValue!=null){
//                                    Long starttimestamp= (Long) snapshot1.child(username).child("startTime").getValue();
//                                    Long endtimestamp= (Long) snapshot1.child(username).child("endTime").getValue();
//
//                                    startTime=Calendar.getInstance();
//                                    endTime=Calendar.getInstance();
//
//                                    startTime.setTimeInMillis(starttimestamp);
//                                    endTime.setTimeInMillis(endtimestamp);
//                                    starthour = startTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
//                                    startminute = startTime.get(Calendar.MINUTE);
//
//                                    endhour = endTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
//                                    endminute = endTime.get(Calendar.MINUTE);
//
//                                    MenuActivity.getInstance().seat.setText(seatNo);
//                                    MenuActivity.getInstance().start.setText(starthour+ " : " + startminute);
//                                    MenuActivity.getInstance().end.setText(endhour+ " : " + endminute);
//
//
//                                    //Log.e("Snapshot main",snapshot.getChildren().toString());
//                                    seatNo = snapshot1.child(username).child("seatNo").getValue().toString();
//                                    //Toast.makeText(MainActivity.this, "seat 1 "+seatNo, Toast.LENGTH_SHORT).show();
//
//                                    String desc = "";
//                                    if (RoomNo.endsWith("3")) {
//                                        desc = RoomNo.substring(0, RoomNo.length() - 1);
//                                        MenuActivity.getInstance().floorNo.setText("Floor No: " + String.valueOf(3));
//                                    } else if (RoomNo.endsWith("2")) {
//                                        desc = RoomNo.substring(0, RoomNo.length() - 1);
//                                        MenuActivity.getInstance().floorNo.setText("Floor No: " + String.valueOf(2));
//                                    }
//                                    MenuActivity.getInstance().seat.setText(seatNo);
//                                    MenuActivity.getInstance().room.setText("Room: "+desc+ " Study");
//                                    MenuActivity.getInstance().unBookBtn.setVisibility(View.VISIBLE);
//                                    MenuActivity.getInstance().cardLayout.setVisibility(View.VISIBLE);
//                                    MenuActivity.getInstance().noSeat.setVisibility(View.GONE);
//                                    MenuActivity.getInstance().unBookBtn.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            //Toast.makeText(this, "Unbooked Tapped"+RoomNo, Toast.LENGTH_SHORT).show();
//                                            //unBookSeat(username,RoomNo);
//                                            snapshot.getRef().child(username).removeValue();
//                                            snapshot1.getRef().child(username).removeValue();
//                                            MenuActivity.getInstance().cardLayout.setVisibility(View.GONE);
//                                            MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);
//                                            MenuActivity.getInstance().unBookBtn.setVisibility(View.GONE);
//                                            MenuActivity.getInstance().hiddenView.setVisibility(View.GONE);
//                                            Toast.makeText(MenuActivity.this, "Unbooked Tapped Main"+RoomNo, Toast.LENGTH_SHORT).show();
//                                        }
//                                    });
//                                }
//                                else if (seatValue == null) {
//                                    //Log.e("Snapshot main",snapshot.getChildren().toString());
//                                    //    Toast.makeText(MainActivity.this, "seat 2 "+seatNo, Toast.LENGTH_SHORT).show();
//                                }
//
//                            }
//                            @Override
//                            public void onCancelled(@NonNull DatabaseError error) {
//
//                            }
//                        });
//                    }
//                    else if (value==null) {
//                        //Log.e("Snapshot main",snapshot.getChildren().toString());
//                        //Toast.makeText(MainActivity.this, "2"+seatNo, Toast.LENGTH_SHORT).show();
//                        MenuActivity.getInstance().cardLayout.setVisibility(View.GONE);
//                        MenuActivity.getInstance().unBookBtn.setVisibility(View.GONE);
//                        MenuActivity.getInstance().hiddenView.setVisibility(View.GONE);
//                        MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);
//
//                    }
//                    MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);
//
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//
//                }
//            });
//
//
//        }
//
//
//        Object[] UserDetail = MainActivity.getActivityInstance().getData();
////        Log.e("userDetail",UserDetail.toString());
//        String name = String.valueOf(UserDetail[0]);
//        String email = String.valueOf(UserDetail[1]);
//        Log.e("name", "" + UserDetail[0]);
//        Log.e("email", "" + UserDetail[1]);
//        int index = email.indexOf('@'); // find the index of the '@' symbol
//        username = email.substring(0, index);
//        ;
//        // Log an error message and return the view
////        username=username.replaceAll("\\d", "");
//        nameTxt.setText(name);
//        Log.e("Menu Activity Name", "MainActivity is not null" + MainActivity.getActivityInstance().name);
//
//        addBookingDetail();
//
//        if (photoUrl != null) {
//            String photo = photoUrl.toString();
//            Glide.with(this)
//                    .load(photo)
//                    .circleCrop()
//                    .into(profilePhoto);
//        } else {
//            String initials = getInitials(name);
//            ColorGenerator generator = ColorGenerator.MATERIAL;
//            int color = generator.getColor(email);
//            TextDrawable drawable = TextDrawable.builder()
//                    .beginConfig()
//                    .width(100)
//                    .height(100)
//                    .endConfig()
//                    .buildRound(initials, color);
//            profilePhoto.setImageDrawable(drawable);
//        }
//        quietBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
////                if (!isBooking) {
//                Intent intent = new Intent(MenuActivity.this,TimeActivity.class);
//                intent.putExtra("RoomClass",QuietRoomLayoutActivity.class);
//                intent.putExtra("isBooking",isBooking);
//                intent.putExtra("AlertRoomName",AlertroomName);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // add this line
//                startActivity(intent);
//
//
////                loadActivity(QuietRoomLayoutActivity.class);
////                } else {
////                    Toast.makeText(MenuActivity.this, "You Can Book Only One Seat", Toast.LENGTH_SHORT).show();
////                }
//            }
//        });
//
//        groupBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//               Intent intent = new Intent(MenuActivity.this,TimeActivity.class);
//                intent.putExtra("RoomClass",GroupRoomLayoutActivity.class);
//                intent.putExtra("isBooking",isBooking);
//                intent.putExtra("AlertRoomName",AlertroomName);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // add this line
//                startActivity(intent);
//            }
//        });
//
//        casualBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(MenuActivity.this,TimeActivity.class);
//                intent.putExtra("RoomClass",CasualRoomLayoutActivity.class);
//                intent.putExtra("isBooking",isBooking);
//                intent.putExtra("AlertRoomName",AlertroomName);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // add this line
//                startActivity(intent);
//            }
//        });
//
//
//        crowdBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                loadActivity(ViewRoomsActivity.class);
//            }
//        });
//        settingsBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                loadActivity(SettingsActivity.class);
//            }
//        });
//        issueBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String email = "admin-library@iiitd.ac.in, library@iiitd.ac.in"; // replace with your email address
//                String subject = "Issue Regarding - ";
//                String body = "Description of the issue...";
//
//                Uri uri = Uri.parse("mailto:" + email + "?subject=" + subject + "&body=" + body);
//
//                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, uri);
//                emailIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                startActivity(Intent.createChooser(emailIntent, "Send email via"));
//            }
//        });
//        alertBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                flag =true;
//                if (flag) {
//
//                    db = FirebaseDatabase.getInstance();
//                    UserReference = db.getReference("Users");
//                    tokenList = new HashSet<>();
//                    UserReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot snapshot) {
//                            value = snapshot.child(username).getValue();
//                            if (value != null) {
//                                roomName = snapshot.child(username).child("room").getValue().toString();
//                                if (roomName.equals("Quiet2") || roomName.equals("Quiet3")) {
//
//                                    SeatReference = db.getReference("Room/" + roomName);
//                                    //userSnapshot.child("endTime").getValue().toString();
//                                    Log.e("seat", SeatReference.toString());
//                                    SeatReference.addListenerForSingleValueEvent(new ValueEventListener() {
//
//                                        @Override
//                                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
//                                            tokenList = new HashSet<>();
//                                            if (snapshot1.exists()) {
//                                                startTime1 = (Long) snapshot1.child(username).child("startTime").getValue();
//                                                endTime1 = (Long) snapshot1.child(username).child("endTime").getValue();
//                                                currentTime = System.currentTimeMillis();
//                                                if (isCurrentTimeInRange(currentTime, startTime1, endTime1)) {
//                                                    flag = false;
//                                                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                                                        userIStart = (Long) userSnapshot.child("startTime").getValue();
//                                                        userIEnd = (Long) userSnapshot.child("endTime").getValue();
//                                                        //currentTime = System.currentTimeMillis();
//                                                        if (isCurrentTimeInRange(currentTime, userIStart, userIEnd) && !userSnapshot.child("email").getValue().toString().equals(email)) {
//                                                            tokenList.add(userSnapshot.child("token").getValue().toString());
//                                                        }
//                                                    }
//                                                    Log.e("token list-shr", "" + tokenList);
//                                                    View dialogView = LayoutInflater.from(MenuActivity.this).inflate(R.layout.alert_pop_up, null);
//
//                                                    // Create the dialog
//                                                    AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this)
//                                                            .setView(dialogView)
//                                                            .setCancelable(false); // Prevent dismiss on outside touch or back press
//
//                                                    AlertDialog dialog = builder.create();
//
////                            // Set click listeners for cancel and OK buttons
//                                                    Button cancelButton = dialogView.findViewById(R.id.dialog_cancel_button);
//                                                    cancelButton.setOnClickListener(new View.OnClickListener() {
//                                                        @Override
//                                                        public void onClick(View v) {
//                                                            // Dismiss the dialog
//                                                            dialog.dismiss();
//                                                            flag = false;
//                                                        }
//                                                    });
//                                                    Button okButton = dialogView.findViewById(R.id.dialog_ok_button);
//                                                    okButton.setOnClickListener(new View.OnClickListener() {
//                                                        @Override
//                                                        public void onClick(View v) {
//                                                            performAlertNotificationOperation(tokenList);
//                                                            // Perform your desired functionality here
//                                                            // ...
//
//                                                            // Dismiss the dialog
//                                                            dialog.dismiss();
//                                                            flag = false;
//                                                        }
//                                                    });
//
//                                                    // Show the dialog
//                                                    dialog.show();
//
//                                                } else {
//                                                    Toast.makeText(MenuActivity.this, "You can use this only during your Booking Duration", Toast.LENGTH_SHORT).show();
//                                                }
//                                            }
//                                        }
//                                        @Override
//                                        public void onCancelled(@NonNull DatabaseError error) {
//
//                                        }
//                                    });
//
//                                } else {
//                                    Toast.makeText(MenuActivity.this, "This feature can be used only for Quiet Room bookings", Toast.LENGTH_SHORT).show();
//                                    flag = false;
//                                }
//
//                            } else {
//                                Toast.makeText(MenuActivity.this, "You need to have a Booking to use this feature", Toast.LENGTH_SHORT).show();
//                                flag = false;
//                            }
//                            flag = false;
//
//                        }
//
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError error) {
//
//                        }
//                    });
//                }
//            }
//        });
//        cardLayout.setOnClickListener(v -> {
//            // If the CardView is already expanded, set its visibility
//            // to gone and change the expand less icon to expand more.
//            if (hiddenView.getVisibility() == View.VISIBLE) {
//                // The transition of the hiddenView is carried out by the TransitionManager class.
//                // Here we use an object of the AutoTransition Class to create a default transition
//                TransitionManager.beginDelayedTransition(cardLayout, new AutoTransition());
//                hiddenView.setVisibility(View.GONE);
//                arrow.setImageResource(R.drawable.arrow_down_ic);
//                Log.e("Arrow down","Arrow 1");
////                arrow.setImageResource(R.drawable.ic_baseline_expand_more_24);
//            }
//
//            // If the CardView is not expanded, set its visibility to
//            // visible and change the expand more icon to expand less.
//            else {
//                TransitionManager.beginDelayedTransition(cardLayout, new AutoTransition());
//                hiddenView.setVisibility(View.VISIBLE);
//                arrow.setImageResource(R.drawable.arrow_up_ic);
//                Log.e("Arrow up","Arrow 1");
////                arrow.setImageResource(R.drawable.ic_baseline_expand_less_24);
//            }
//        });
//
//        db = FirebaseDatabase.getInstance();
//        UserReference = db.getReference("Users");
//        UserReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                value = snapshot.child(username).getValue();
//                if (value != null) {
//                    AlertroomName = snapshot.child(username).child("room").getValue().toString();
//                    Toast.makeText(MenuActivity.this, "user found", Toast.LENGTH_SHORT).show();
//                    isBooking = true;
//                    noSeat.setVisibility(View.GONE);
//                    seatBooked.setVisibility(View.VISIBLE);
//                    cardLayout.setVisibility(View.VISIBLE);
//                } else {
//                    Toast.makeText(MenuActivity.this, "user not found", Toast.LENGTH_SHORT).show();
//                    isBooking = false;
//                    noSeat.setVisibility(View.VISIBLE);
//                    seatBooked.setVisibility(View.GONE);
//
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
////        detailsCard.setOnClickListener(v -> {
////            // If the CardView is already expanded, set its visibility
////            // to gone and change the expand less icon to expand more.
////            if (hiddenView.getVisibility() == View.VISIBLE) {
////                // The transition of the hiddenView is carried out by the TransitionManager class.
////                // Here we use an object of the AutoTransition Class to create a default transition
////                TransitionManager.beginDelayedTransition(detailsCard, new AutoTransition());
////                hiddenView.setVisibility(View.GONE);
////                arrow.setImageResource(R.drawable.arrow_down_ic);
//////                arrow.setImageResource(R.drawable.ic_baseline_expand_more_24);
////            }
////
////            // If the CardView is not expanded, set its visibility to
////            // visible and change the expand more icon to expand less.
////            else {
////                TransitionManager.beginDelayedTransition(detailsCard, new AutoTransition());
////                hiddenView.setVisibility(View.VISIBLE);
////                arrow.setImageResource(R.drawable.arrow_up_ic);
//////                arrow.setImageResource(R.drawable.ic_baseline_expand_less_24);
////            }
////        });
//        refreshBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(refreshBtn, "rotation", 0f, 360f);
//                rotationAnimator.setDuration(2000);
//                rotationAnimator.start();
//                refreshDetail();
//            }
//        });
//
//
//    }
//
//
//        private void performAlertNotificationOperation(Set<String> utokenList) {
//            Log.e(" Alert Token List in Notification Operation - ", "" + utokenList);
//            Toast.makeText(MenuActivity.this, "Notifying " + utokenList.size() + " student(s) around you to maintain silence", Toast.LENGTH_SHORT).show();
//            String title = "Silence in " + AlertroomName;
//            String message = "Please maintain silence in " + AlertroomName + ". Students around you are getting disturbed.";
//
//            for (String token : utokenList) {
//                sendNotification(token, title, message);
//            }
//        }
//
//
//    private void sendNotification(String token, String title, String message) {
//        RequestQueue queue = Volley.newRequestQueue(this);
//
//        // Construct JSON body for POST request
//        JSONObject notificationBody = new JSONObject();
//        try {
//            notificationBody.put("to", token);
//
//            JSONObject data = new JSONObject();
//            data.put("title", title);
//            data.put("message", message);
//
//            notificationBody.put("data", data);
//        } catch (JSONException e) {
//            Log.e(TAG, "Error creating JSON body", e);
//        }
//
//        // Construct POST request
//        JsonObjectRequest request = new JsonObjectRequest(
//                Request.Method.POST,
//                FCM_API_URL,
//                notificationBody,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        Log.e("Notification sent successfully",""+response);
////                        Log.i(TAG, "Notification sent successfully: " + response);
//                        Toast.makeText(MenuActivity.this, "Notification sent successfully", Toast.LENGTH_SHORT).show();
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        String errorResponse = new String(error.networkResponse.data, StandardCharsets.UTF_8);
//                        Log.e(TAG, "Error sending notification: " + errorResponse, error);
//                        Toast.makeText(MenuActivity.this, "Error sending notification: " + errorResponse, Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//            @Override
//            public Map<String, String> getHeaders() {
//                Map<String, String> headers = new HashMap<>();
//                headers.put("Content-Type", "application/json");
//                headers.put("Authorization", "key=" + SERVER_KEY);
//                return headers;
//            }
//        };
//
//        // Add POST request to Volley queue
//        queue.add(request);
//    }
//
////    private void getAlertToken() {
////
////        currentTime= System.currentTimeMillis();
////        FirebaseDatabase database = FirebaseDatabase.getInstance();
////        DatabaseReference UserRef = database.getReference("Room/"+AlertroomName+"/"+username);
////        UserRef.addListenerForSingleValueEvent(new ValueEventListener() {
////            @Override
////            public void onDataChange(DataSnapshot dataSnapshot) {
////                if (dataSnapshot.exists()) {
////                    Long startTime = (Long) dataSnapshot.child("startTime").getValue();
////                    Long endTime = (Long) dataSnapshot.child("endTime").getValue();
////                    if (isCurrentTimeInRange(currentTime, startTime, endTime))
////                        canSend = true;
////                    else {
////                        canSend = false;
////                    }
////                }
////                checkSend++;
////            }
////            @Override
////            public void onCancelled(DatabaseError databaseError) {
////                Log.e(TAG, "onCancelled", databaseError.toException());
////            }
////        });
////
////        DatabaseReference roomRef = database.getReference("Room").child(AlertroomName);
////        roomRef.addValueEventListener(new ValueEventListener() {
////            @Override
////            public void onDataChange(@NonNull DataSnapshot snapshot) {
////                for (DataSnapshot personSnapshot : snapshot.getChildren()) {
////                    userIStart = (Long) personSnapshot.child("startTime").getValue();
////                    userIEnd = (Long) personSnapshot.child("endTime").getValue();
////                    if (isCurrentTimeInRange(currentTime, userIStart, userIEnd) && personSnapshot.child("email").getValue().toString() != email ) { //&& personSnapshot.child("email").getValue().toString() != email
////                        userTokenList.add(personSnapshot.child("token").getValue().toString());
////                    }
////
////                    // Do something with the values (e.g. store in a list or array)
////                    // ...
////                }
////                Log.e("UserTokenList inside the OnDataChange - ",""+userTokenList);
////                checkSend++;
////            }
////
////            @Override
////            public void onCancelled(@NonNull DatabaseError error) {
////                // Handle the error
////                // ...
////            }
////        });
////
////      nSend==true)
////           performAlertNotificationOperation(); if(ca
////       else Toast.makeText(MenuActivity.this, "You can use this only during your Booking Duration", Toast.LENGTH_SHORT).show();
////
////    }
//
//    public boolean isCurrentTimeInRange(long currentTime, long startTime, long endTime) {
//        return currentTime >= startTime && currentTime <= endTime;
//    }
//
//    private void refreshDetail() {
//        Object[] UserDetail = MainActivity.getActivityInstance().getData();
////        Log.e("userDetail",UserDetail.toString());
//        String name = String.valueOf(UserDetail[0]);
//        String email = String.valueOf(UserDetail[1]);
//        int index = email.indexOf('@'); // find the index of the '@' symbol
//        String username = email.substring(0, index);
//        ;
//        db = FirebaseDatabase.getInstance();
//        UserReference = db.getReference("Users");
//        UserReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                value = snapshot.child(username).getValue();
//                if (value != null) {
//                    roomName = snapshot.child(username).child("room").getValue().toString();
//                    SeatReference = db.getReference("Room/" + roomName);
//                    Log.e("seat", SeatReference.toString());
//                    SeatReference.addValueEventListener(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
//
//                            Long endtimestamp = (Long) snapshot1.child(username).child("endTime").getValue();
//                            if (endtimestamp != null) {
//                                if (System.currentTimeMillis() <= Long.parseLong(endtimestamp.toString())) {
//
//                                } else {
//                                    SeatReference.getRef().child(username).removeValue();
//                                    UserReference.getRef().child(username).removeValue();
//                                }
//                            }
//                        }
//
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError error) {
//
//                        }
//                    });
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
////        finish();
////        startActivity(getIntent());
//    }
//
//    private void loadActivity(Class<?> activityClass) {
//
//        Intent intent = new Intent(MenuActivity.this, activityClass);
//        intent.putExtra("isBooking",isBooking);
//        intent.putExtra("AlertRoomName",AlertroomName);
//        startActivity(intent);
//
//    }
//
//    private String getInitials(String name) {
//        String[] splitName = name.split("\\s+");
//        String firstName = splitName[0];
//        return String.valueOf(firstName.charAt(0)).toUpperCase();
//    }
//
//    public static MenuActivity getInstance() {
//        return instance;
//    }
//
////    public String getUsername() {
////        Object[] UserDetail = MainActivity.getActivityInstance().getData();
//////        Log.e("userDetail",UserDetail.toString());
////        String name = String.valueOf(UserDetail[0]);
////        String email = String.valueOf(UserDetail[1]);
////        Log.e("name", "" + UserDetail[0]);
////        Log.e("email", "" + UserDetail[1]);
////        int index = email.indexOf('@'); // find the index of the '@' symbol
////        String username = email.substring(0, index);
////        return username;
////    }
//
//    public void addBookingDetail() {
//        Object[] UserDetail = MainActivity.getActivityInstance().getData();
////        Log.e("userDetail",UserDetail.toString());
//        String name = String.valueOf(UserDetail[0]);
//        String email = String.valueOf(UserDetail[1]);
//        Log.e("name", "" + UserDetail[0]);
//        Log.e("email", "" + UserDetail[1]);
//        int index = email.indexOf('@'); // find the index of the '@' symbol
//        String username = email.substring(0, index);
//
//        db = FirebaseDatabase.getInstance();
//        UserReference = db.getReference("Users");
//
//        UserReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                Long allUserCount = snapshot.getChildrenCount();
//                //Log.e("Children",snapshot.toString());
//                Log.e("count of all user in menu", "" + snapshot.getChildrenCount());
//                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    allUserList.add(userSnapshot.getKey());
//                }
//
//                Log.e("User List menu", "" + allUserList);
//                if (allUserCount == 0 || allUserList.isEmpty()) {
//
//                    allUserList.clear();
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(MenuActivity.this, "error in fetching user list", Toast.LENGTH_SHORT).show();
//            }
//        });
//        Log.e("UserList", "" + allUserList);
//
//
//        if (allUserList.contains(username)) {
//            Log.e("ho", "ho");
//            db = FirebaseDatabase.getInstance();
//            UserReference = db.getReference("Users");
//
//            UserReference.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    value = snapshot.child(username).getValue();
//                    if (value != null) {
//                        roomName = snapshot.child(username).child("room").getValue().toString();
//                        String desc;
//                        if (roomName.endsWith("3")) {
//                            desc = roomName.substring(0, roomName.length() - 1) + " Study";
//                            floorNo.setText("Floor No: " + String.valueOf(3));
//
//                        } else if (roomName.endsWith("2")) {
//                            desc = roomName.substring(0, roomName.length() - 1) + " Study";
//                            floorNo.setText("Floor No: " + String.valueOf(2));
//                        } else {
//                            desc = roomName;
//                        }
//                        room.setText("Room: "+desc +" Study");
//                        SeatReference = db.getReference("Room/" + roomName);
//                        Log.e("seat", SeatReference.toString());
//                        SeatReference.addValueEventListener(new ValueEventListener() {
//                            @Override
//                            public void onDataChange(@NonNull DataSnapshot snapshot1) {
//                                Log.e("seat", snapshot1.child(username).toString());
//                                seatValue = snapshot1.child(username).getValue();
//                                if (seatValue != null) {
//                                    DataSnapshot seatSnanpshot = snapshot1.child(username).child("seatNo");
//                                    //Log.e("seatsnapshot",seatSnanpshot.getValue().toString());
//                                    seatNo = seatSnanpshot.getValue().toString();
//
//                                    Long starttimestamp = (Long) snapshot1.child(username).child("startTime").getValue();
//                                    Long endtimestamp = (Long) snapshot1.child(username).child("endTime").getValue();
//
//                                    startTime = Calendar.getInstance();
//                                    endTime = Calendar.getInstance();
//
//                                    startTime.setTimeInMillis(starttimestamp);
//                                    endTime.setTimeInMillis(endtimestamp);
//                                    starthour = startTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
//                                    startminute = startTime.get(Calendar.MINUTE);
//
//                                    endhour = endTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
//                                    endminute = endTime.get(Calendar.MINUTE);
//                                    seat.setText(seatNo);
//                                    start.setText(starthour + " : " + startminute);
//                                    end.setText(endhour + " : " + endminute);
//
////                                    BookingDetail.setText(desc+" \n Seat number: "+seatNo+"\n"+starthour+":"+startminute+"   "+endhour+":"+endminute);
//                                    unBookBtn.setVisibility(View.VISIBLE);
//                                    seatBooked.setVisibility(View.VISIBLE);
//                                    arrow.setImageResource(R.drawable.arrow_down_ic);
//                                    Log.e("Arrow down","Arrow 2");
//                                    unBookBtn.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            snapshot.getRef().child(username).removeValue();
//                                            snapshot1.getRef().child(username).removeValue();
////                                            BookingDetail.setText("You have not booked your seat");
//                                            noSeat.setVisibility(View.VISIBLE);
//                                            unBookBtn.setVisibility(View.GONE);
//                                            cardLayout.setVisibility(View.GONE);
//                                            hiddenView.setVisibility(View.GONE);
//                                            Toast.makeText(MenuActivity.this, "Unbooked Tapped Menu" + roomName, Toast.LENGTH_SHORT).show();
//                                        }
//                                    });
//                                }
////                        Log.e("starttime",""+starthour+""+);
////                        Log.e("starttime",snapshot.child(username).child("endTime").getValue().toString());
//                            }
//
//                            @Override
//                            public void onCancelled(@NonNull DatabaseError error) {
//                                Toast.makeText(MenuActivity.this, "Fail to get Seat data ", Toast.LENGTH_SHORT).show();
//                                Log.e("Error", "Fail to get Seat data ");
//                            }
//                        });
//
//                    }
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//                    Toast.makeText(MenuActivity.this, "Fail to get userData", Toast.LENGTH_SHORT).show();
//                    Log.e("Error", "Fail to get userData");
//                }
//            });
//
//        } else {
//            noSeat.setVisibility(View.VISIBLE);
//            cardLayout.setVisibility(View.GONE);
//            hiddenView.setVisibility(View.GONE);
//
//        }
//    }
//
//    @Override
//    public void onBackPressed() {
//        if (doubleBackToExitPressedOnce) {
//            super.onBackPressed();
//            return;
//        }
//
//
//        this.doubleBackToExitPressedOnce = true;
//        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
//
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                doubleBackToExitPressedOnce = false;
//            }
//        }, 4000); // Delay for 4 seconds
//    }
//
//}