package com.example.libraryseatbookingsystem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private boolean doubleBackToExitPressedOnce = false;
    private Handler mHandler = new Handler();
    Button loginBtn;
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;

    private static MainActivity INSTANCE;
    private static boolean openInitialMessage = false;

    String email, name;
    Uri photoUrl;

    FirebaseDatabase db;
    DatabaseReference UserReference,SeatReference;
    static String seatNo="0",RoomNo="1";
    Calendar startTime=null;
    Calendar endTime=null;
    int starthour=0,startminute=0,endhour=0,endminute=0;
    //static Set<String> allUserList = new HashSet<String>();
    Object value,seatValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        if(intent.hasExtra("displayPopup")){
            openInitialMessage = true;
        }
        INSTANCE=this;
        //Toast.makeText(INSTANCE, "On Create", Toast.LENGTH_SHORT).show();
        loginBtn=findViewById(R.id.loginBtn);
        gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .build();
        gsc = GoogleSignIn.getClient(this,gso);

        //Checking if the user is already signedIn
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null && isValidEmail(account.getEmail())) {
            email = account.getEmail();
            name = account.getDisplayName();
            photoUrl = account.getPhotoUrl();
            HomeActivity();
            //addBookingDetail();
            int index = email.indexOf('@'); // find the index of the '@' symbol
            String username = email.substring(0, index);
            //MenuFragment.getInstance().BookingDetail.setText("hello");

            db = FirebaseDatabase.getInstance();
            UserReference = db.getReference("Users");
            UserReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    value=snapshot.child(username).getValue();
                    //Toast.makeText(MainActivity.this, "on Data changed user", Toast.LENGTH_SHORT).show();

                    if (value!=null){
                        //Log.e("Snapshot main",snapshot.getChildren().toString());
                        RoomNo=snapshot.child(username).child("room").getValue().toString();
                        //Toast.makeText(MainActivity.this, "1"+seatNo, Toast.LENGTH_SHORT).show();
                        //MenuFragment.getInstance().BookingDetail.setText("hello"+snapshot.child(username));
                        //Log.e("room number",seatNo);
                        //Toast.makeText(MainActivity.this, "3"+RoomNo, Toast.LENGTH_SHORT).show();
                        SeatReference = db.getReference("Room/"+RoomNo);
                        //Log.e("Seat In Main",SeatReference.toString());
                        //Toast.makeText(INSTANCE, "Seat "+SeatReference, Toast.LENGTH_LONG).show();
                        SeatReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot1) {
                                //Toast.makeText(MainActivity.this, "on Data changed seat", Toast.LENGTH_SHORT).show();
                                //Toast.makeText(MainActivity.this, "seat"+snapshot1.child(username), Toast.LENGTH_LONG).show();

                                Log.e("Snapshot Seat", snapshot1.child(username).toString());
                                seatValue = snapshot1.child(username).getValue();

                                if (seatValue!=null){
                                    Long starttimestamp= (Long) snapshot1.child(username).child("startTime").getValue();
                                    Long endtimestamp= (Long) snapshot1.child(username).child("endTime").getValue();

                                    startTime=Calendar.getInstance();
                                    endTime=Calendar.getInstance();

                                    startTime.setTimeInMillis(starttimestamp);
                                    endTime.setTimeInMillis(endtimestamp);
                                    starthour = startTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
                                    startminute = startTime.get(Calendar.MINUTE);

                                    endhour = endTime.get(Calendar.HOUR_OF_DAY); // 24-hour clock
                                    endminute = endTime.get(Calendar.MINUTE);

                                    MenuActivity.getInstance().seat.setText(seatNo);
                                    MenuActivity.getInstance().start.setText(starthour+ " : " + startminute);
                                    MenuActivity.getInstance().end.setText(endhour+ " : " + endminute);


                                    //Log.e("Snapshot main",snapshot.getChildren().toString());
                                    seatNo = snapshot1.child(username).child("seatNo").getValue().toString();
                                    //Toast.makeText(MainActivity.this, "seat 1 "+seatNo, Toast.LENGTH_SHORT).show();

                                    String desc = "";
                                    if (RoomNo.endsWith("3")) {
                                        desc = RoomNo.substring(0, RoomNo.length() - 1);
                                        MenuActivity.getInstance().floorNo.setText("Floor No: " + String.valueOf(2));
                                    } else if (RoomNo.endsWith("2")) {
                                        desc = RoomNo.substring(0, RoomNo.length() - 1);
                                        MenuActivity.getInstance().floorNo.setText("Floor No: " + String.valueOf(2));
                                    }
                                    MenuActivity.getInstance().seat.setText(seatNo);
                                    MenuActivity.getInstance().room.setText("Room: "+desc + " Study");
                                    MenuActivity.getInstance().unBookBtn.setVisibility(View.VISIBLE);
                                    MenuActivity.getInstance().cardLayout.setVisibility(View.VISIBLE);
                                    MenuActivity.getInstance().noSeat.setVisibility(View.GONE);
                                    MenuActivity.getInstance().unBookBtn.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            //Toast.makeText(this, "Unbooked Tapped"+RoomNo, Toast.LENGTH_SHORT).show();
                                            //unBookSeat(username,RoomNo);
                                            snapshot.getRef().child(username).removeValue();
                                            snapshot1.getRef().child(username).removeValue();
                                            MenuActivity.getInstance().cardLayout.setVisibility(View.GONE);
                                            MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);
                                            MenuActivity.getInstance().unBookBtn.setVisibility(View.GONE);
                                            MenuActivity.getInstance().hiddenView.setVisibility(View.GONE);
//                                            Toast.makeText(MainActivity.this, "Unbooked Tapped Main"+RoomNo, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                                else if (seatValue == null) {
                                    //Log.e("Snapshot main",snapshot.getChildren().toString());
                                    //    Toast.makeText(MainActivity.this, "seat 2 "+seatNo, Toast.LENGTH_SHORT).show();
                                }

                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                    else if (value==null) {
                        //Log.e("Snapshot main",snapshot.getChildren().toString());
                        //Toast.makeText(MainActivity.this, "2"+seatNo, Toast.LENGTH_SHORT).show();
                        MenuActivity.getInstance().cardLayout.setVisibility(View.GONE);
                        MenuActivity.getInstance().unBookBtn.setVisibility(View.GONE);
                        MenuActivity.getInstance().hiddenView.setVisibility(View.GONE);
                        MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);

                    }
                    MenuActivity.getInstance().noSeat.setVisibility(View.VISIBLE);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });



            //Toast.makeText(INSTANCE, "called", Toast.LENGTH_SHORT).show();
            return;
        }


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignIn();
            }
        });

    }

    public void unBookSeat(String username, String roomNo) {



    }


    private void SignIn(){
        Intent intent = gsc.getSignInIntent();
        startActivityForResult(intent,100);
    }
    private boolean isValidEmail(String email) {
        return email.endsWith("@iiitd.ac.in");
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        Log.d("data", String.valueOf(data));
//        Toast.makeText(INSTANCE, "On Activity Result", Toast.LENGTH_SHORT).show();

        if(requestCode==100){
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try{
                GoogleSignInAccount account =task.getResult(ApiException.class);
                email = account.getEmail();
                name = account.getDisplayName();
                if(isValidEmail(email)) {
                    HomeActivity();
                    //Toast.makeText(INSTANCE, "called-2", Toast.LENGTH_SHORT).show();
                }

                else{
                    Toast.makeText(this, "Email should be from IIIT Delhi", Toast.LENGTH_SHORT).show();
                    gsc.signOut();
                }
            }
            catch(ApiException e){
//                Toast.makeText(this, "ERROR occurred while Login", Toast.LENGTH_SHORT).show();
                Log.i("error", e.toString());
            }
        }
    }
    private void HomeActivity(){
        finish();

        Intent intent = new Intent(getApplicationContext(),MenuActivity.class);
        if (openInitialMessage){
            openInitialMessage = false;
            intent.putExtra("displayPopup", true);}
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 4000); // Delay for 4 seconds
    }

    public static MainActivity getActivityInstance()
    {
        return INSTANCE;
    }

    public Object[] getData()
    {
        String[] strArray = new String[2];
        strArray[0] = this.name;
        strArray[1] = this.email;
        Log.e("main",""+strArray);
        Log.e("main",""+strArray[0]);
        Log.e("main",""+strArray[1]);
        return strArray;
    }

}