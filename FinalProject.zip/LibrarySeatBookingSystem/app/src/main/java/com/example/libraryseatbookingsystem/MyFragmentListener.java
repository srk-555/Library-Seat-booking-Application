package com.example.libraryseatbookingsystem;

public interface MyFragmentListener {
    void onSomeEvent();
}
